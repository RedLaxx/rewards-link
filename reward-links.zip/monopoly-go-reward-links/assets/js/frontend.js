(function () {
	'use strict';

	var DATE_OPTS = { month: 'short', day: 'numeric' };
	var TIME_OPTS = { hour: 'numeric', minute: '2-digit', timeZoneName: 'short' };
	var TIME_OPTS_NO_ZONE = { hour: 'numeric', minute: '2-digit' };

	function formatAvailability( start, end ) {
		try {
			var sameDay = start.toDateString() === end.toDateString();
			var startStr = start.toLocaleDateString( undefined, DATE_OPTS ) + ', ' + start.toLocaleTimeString( undefined, TIME_OPTS_NO_ZONE );
			var endStr = ( sameDay ? '' : end.toLocaleDateString( undefined, DATE_OPTS ) + ', ' ) + end.toLocaleTimeString( undefined, TIME_OPTS );
			return startStr + ' through ' + endStr;
		} catch ( e ) {
			return '';
		}
	}

	function formatUpdated( date ) {
		try {
			return date.toLocaleDateString( undefined, DATE_OPTS ) + ', ' + date.toLocaleTimeString( undefined, TIME_OPTS );
		} catch ( e ) {
			return '';
		}
	}

	function updateCard( card ) {
		var startAttr = card.getAttribute( 'data-start' );
		var endAttr   = card.getAttribute( 'data-end' );
		if ( ! startAttr || ! endAttr ) { return; }

		var start = new Date( startAttr );
		var end   = new Date( endAttr );
		var now   = new Date();

		var statusEl = card.querySelector( '[data-mgrl-status]' );
		var timeEl   = card.querySelector( '[data-mgrl-time]' );
		var claimEl  = card.querySelector( '[data-mgrl-claim]' );

		card.classList.remove( 'mgrl-live', 'mgrl-upcoming', 'mgrl-ended' );

		var label, ended = false;
		if ( now < start ) {
			card.classList.add( 'mgrl-upcoming' );
			label = 'Upcoming';
		} else if ( now > end ) {
			card.classList.add( 'mgrl-ended' );
			label = 'Ended';
			ended = true;
		} else {
			card.classList.add( 'mgrl-live' );
			label = 'Live';
		}

		if ( statusEl ) { statusEl.textContent = label; }
		if ( timeEl ) { timeEl.textContent = formatAvailability( start, end ); }

		if ( claimEl ) {
			var shouldDisable = ended && claimEl.getAttribute( 'data-disable-on-ended' ) === '1';
			claimEl.classList.toggle( 'mgrl-claim-disabled', shouldDisable );
		}
	}

	function updateBadge( el ) {
		var attr = el.getAttribute( 'data-mgrl-updated' );
		if ( ! attr ) { return; }
		var textEl = el.querySelector( '[data-mgrl-updated-text]' );
		if ( ! textEl ) { return; }
		textEl.textContent = formatUpdated( new Date( attr ) );
	}

	function tick() {
		document.querySelectorAll( '[data-mgrl-card]' ).forEach( updateCard );
		document.querySelectorAll( '[data-mgrl-updated]' ).forEach( updateBadge );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		tick();
		setInterval( tick, 15000 ); // re-check every 15s so status flips live without a page reload
	} );
})();
