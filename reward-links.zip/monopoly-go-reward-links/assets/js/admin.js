(function ($) {
	'use strict';

	$(function () {
		var cardIndex = $('#mgrl-cards-rows .mgrl-card-row').length;

		/* ---------- Add / remove / reorder cards ---------- */

		$('#mgrl-add-card').on('click', function (e) {
			e.preventDefault();
			var template = $('#mgrl-card-row-template').html();
			var html = template.split('__INDEX__').join(cardIndex++);
			$('#mgrl-cards-rows').append(html);
		});

		$(document).on('click', '.mgrl-remove-card', function (e) {
			e.preventDefault();
			if (window.confirm('Remove this reward card?')) {
				$(this).closest('.mgrl-card-row').remove();
			}
		});

		// Reordering just moves the whole row in the DOM — browsers submit form
		// fields in document order regardless of the index baked into each
		// field's name attribute, so no renumbering is needed for save order
		// to follow the new arrangement.
		$(document).on('click', '.mgrl-move-up', function (e) {
			e.preventDefault();
			var $row = $(this).closest('.mgrl-card-row');
			var $prev = $row.prev('.mgrl-card-row');
			if ($prev.length) { $row.insertBefore($prev); }
		});

		$(document).on('click', '.mgrl-move-down', function (e) {
			e.preventDefault();
			var $row = $(this).closest('.mgrl-card-row');
			var $next = $row.next('.mgrl-card-row');
			if ($next.length) { $row.insertAfter($next); }
		});

		/* Keep the row header label readable while editing */
		$(document).on('input', '.mgrl-card-title', function () {
			var $row = $(this).closest('.mgrl-card-row');
			var val = $(this).val().trim();
			$row.find('.mgrl-card-row-title').text(val || 'New Reward Card');
		});

		/* ---------- Rewards sub-repeater (per card) ---------- */

		$(document).on('click', '.mgrl-add-reward', function (e) {
			e.preventDefault();
			var $cardRow = $(this).closest('.mgrl-card-row');
			var cardIdx = $cardRow.data('index');
			var $container = $cardRow.find('.mgrl-rewards-rows').first();
			var rewardIdx = $container.data('next-reward-index') || 0;

			var template = $('#mgrl-reward-row-template').html();
			var html = template.split('__CARD_INDEX__').join(cardIdx).split('__REWARD_INDEX__').join(rewardIdx);
			$container.append(html);
			$container.data('next-reward-index', rewardIdx + 1);
		});

		$(document).on('click', '.mgrl-remove-reward', function (e) {
			e.preventDefault();
			$(this).closest('.mgrl-reward-row').remove();
		});

		/* ---------- Add new reward type via AJAX (from inside a reward row) ---------- */

		$(document).on('click', '.mgrl-add-type-toggle', function () {
			$(this).closest('.mgrl-reward-row').find('.mgrl-add-type-row').slideToggle(150);
		});

		$(document).on('click', '.mgrl-add-type-save', function () {
			var $btn = $(this);
			var $row = $btn.closest('.mgrl-add-type-row');
			var $rewardRow = $btn.closest('.mgrl-reward-row');
			var $select = $rewardRow.find('.mgrl-reward-type');
			var name = $row.find('.mgrl-new-type-name').val().trim();
			var icon = $row.find('.mgrl-new-type-icon').val();
			if (!name) { return; }

			$btn.prop('disabled', true).siblings('.spinner').addClass('is-active');

			$.post(MGRL_Admin.ajaxUrl, {
				action: 'mgrl_add_reward_type',
				nonce: MGRL_Admin.nonce,
				name: name,
				icon: icon
			}).done(function (res) {
				if (res.success) {
					var opt = new Option(res.data.name, res.data.term_id, true, true);
					$(opt).attr('data-icon', res.data.icon || '');
					$select.append(opt).trigger('change');
					$row.find('.mgrl-new-type-name').val('');
					$row.find('.mgrl-new-type-icon').val('');
					$row.find('.mgrl-icon-preview').empty();
					$row.slideUp(150);
				} else {
					alert(res.data && res.data.message ? res.data.message : 'Could not add reward.');
				}
			}).fail(function () {
				alert('Could not add reward. Please try again.');
			}).always(function () {
				$btn.prop('disabled', false).siblings('.spinner').removeClass('is-active');
			});
		});

		/* ---------- Icon / image picker: reused across the card's Title Image field, ---------- */
		/* the per-reward bigger-image field, the quick-add reward row, and the Reward Types screen. */

		$(document).on('click', '.mgrl-upload-icon-btn', function (e) {
			e.preventDefault();
			var $button = $(this);
			var $scope = $button.closest('td, .form-field, .mgrl-add-type-row, .mgrl-reward-image-field');
			var $hidden = $scope.find('input[type="hidden"]').first();
			var $preview = $scope.find('.mgrl-icon-preview').first();

			var frame = wp.media({ title: 'Select Image', multiple: false, library: { type: 'image' } });
			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				$hidden.val(attachment.url);
				$preview.html('<img src="' + attachment.url + '" style="max-width:50px;height:auto;display:block;margin-top:8px;" />');
				$scope.find('.mgrl-image-clear').show();
			});
			frame.open();
		});

		$(document).on('click', '.mgrl-image-clear', function (e) {
			e.preventDefault();
			var $button = $(this);
			var $scope = $button.closest('td, .form-field, .mgrl-add-type-row, .mgrl-reward-image-field');
			$scope.find('input[type="hidden"]').first().val('');
			$scope.find('.mgrl-icon-preview').first().empty();
			$button.hide();
		});
	});
})(jQuery);
