=== Monopoly GO Reward Links ===
Version: 1.4.0

== What's new in v1.4.0 ==

* Reorder cards: each card in the post editor now has ▲ / ▼ buttons
  to move it up or down — the order you arrange them in is exactly
  the order they render in on the front end.
* 5 new Card Templates (8 total): Neon Arcade, Sunset Pop, Ocean
  Breeze, Royal Purple, and Minimal Mono, alongside the original
  Board Green, Midnight Gold, and Classic Light.
* New Card Shape setting: Rounded (default), Sharp Corners, or Extra
  Rounded / Pill — affects the card, buttons, and reward pills.
* 2 new Tile Sizes (5 total): Compact and Extra Large, alongside
  Small, Medium, and Large.
* "Mark as New" toggle per card — shows a small "New" badge on the
  card (top-left, opposite the status badge).
* Title Image — each card can now carry its own image next to the
  title (e.g. a small logo or banner), separate from the reward
  icons.
* Bigger reward images — each individual reward can optionally carry
  its own larger image instead of the small reward-type icon. Set
  it per reward in the "Bigger Image" field; leave it blank and that
  reward keeps using its type's small icon as before.

All of the above repairs itself automatically on your existing
install the next time any page loads — no manual step needed.

== What's new in v1.3.0 ==

* Fixed: a card with no Start/End date was being silently dropped
  entirely on save — the whole card just vanished with no warning.
  Dates are now genuinely optional: leave both blank and the card
  displays normally, just without a status badge or availability
  line (there's no time window to show). This repairs itself
  automatically on existing installs — no manual step needed.
* Confirmed/kept: leaving the Claim URL blank was already handled —
  the card just doesn't show a claim button.
* New per-post toggle: "Show the 'Updated' badge…", right in the
  post editor's Reward Links box (above the card list). Turning it
  off only affects that one post — every other post keeps showing
  its own badge as usual. This is separate from anything in Settings
  on purpose, since it's a per-post choice, not a site-wide one.

== What's new in v1.2.0 ==

* Fixed: the quick "+ New Reward" button inside a reward card (the
  fast, everyday way to add a reward type) had no icon field at all
  — only a name. You'd have to separately visit Reward Types to add
  an icon afterward. It now has its own icon picker, so name + icon
  are set together in one step.
* New dedicated "Reward Links" admin menu, matching the Events
  plugin's setup:
  - Settings: Card Template (Board Green / Midnight Gold / Classic
    Light — same three as Events), Card Title Color override, Tile
    Size (Small/Medium/Large), Claim Button Text, and a toggle for
    whether the Claim button disables itself once a card ends.
  - Reward Types: add/rename reward types and set their icons —
    same screen as before, now easier to find.


== What's new in v1.1.0 ==

Recolored to match the Monopoly GO Events plugin: dark board-green
cards, gold accents and claim button, same green/yellow/red for
Live/Upcoming/Ended. Purely visual — no functional changes.

== What this does ==

Modeled on the reward-link cards from the Monopoly GO Wiki screenshot:
an "Updated" badge, a title, one or more rewards (each with its own
icon and quantity), an availability window, and a claim button.

* Open any Post or Page in wp-admin — there's a "Monopoly GO Reward
  Links" box below the content editor. Click "+ Add Reward Card" to
  add as many cards as you like to that post.
* Each card: Title, Start/End (GMT+1 — controls Live/Upcoming/Ended
  status), a Claim URL, and a Rewards list (each reward = a saved,
  reusable type like "Rolls" or "Loot Box", plus a quantity).
* Reward types are saved the first time you create one ("+ New
  Reward" inside any reward row) and are selectable from then on —
  same reusable pattern as Event Names in the Events plugin. Manage
  them (rename, change icon) under Posts → Reward Types.
* Drop [mgrl_rewards] anywhere in that post's content to render the
  cards right there.

== Live status & time sync ==

Same time model as the Monopoly GO Events plugin: enter Start/End in
a fixed GMT+1. On the front end, each card's status (Live / Upcoming
/ Ended, shown as a colored badge and accent bar) and its displayed
availability window are computed against each visitor's own device
clock — so a US visitor sees the correct local time and an accurate
status, not GMT+1 literally. Rechecked every 15 seconds so a card
flips from Upcoming to Live without a page reload. Ended cards get
their Claim button disabled automatically.

== The "Updated" badge ==

Shown at the top of the cards whenever at least one exists on that
post. It reflects the most recent time any of that post's reward
cards were saved, converted to the visitor's local time client-side
— matching the "Updated Aug 14, 10:24 AM EDT" badge from the
reference screenshot.

== Shortcode ==

[mgrl_rewards]
  Renders the reward cards added to whichever post/page this
  shortcode sits inside. Optionally: [mgrl_rewards post_id="123"]
  to pull another post's cards instead.

== Install ==

1. Plugins → Add New → Upload Plugin → select the zip → Activate.
2. Edit any post/page, scroll to "Monopoly GO Reward Links", add
   your first card and its rewards, then insert [mgrl_rewards].

This is v1 — built to be extended. Good next additions: an
appearance/settings page (matching the Events plugin's Card Template
options), and a "claim count" or click-tracking feature.
