<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGRL_Ajax {

	public static function init() {
		add_action( 'wp_ajax_mgrl_add_reward_type', array( __CLASS__, 'add_reward_type' ) );
	}

	public static function add_reward_type() {
		check_ajax_referer( 'mgrl_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mgrl' ) ) );
		}

		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		if ( '' === $name ) {
			wp_send_json_error( array( 'message' => __( 'Name cannot be empty.', 'mgrl' ) ) );
		}
		$icon = isset( $_POST['icon'] ) ? esc_url_raw( wp_unslash( $_POST['icon'] ) ) : '';

		$existing = term_exists( $name, 'mgrl_reward_type' );
		if ( $existing ) {
			$term_id = is_array( $existing ) ? $existing['term_id'] : $existing;
			if ( $icon ) {
				update_term_meta( $term_id, 'mgrl_icon', $icon );
			}
			wp_send_json_success( array(
				'term_id'  => $term_id,
				'name'     => $name,
				'icon'     => get_term_meta( $term_id, 'mgrl_icon', true ),
				'existing' => true,
			) );
		}

		$result = wp_insert_term( $name, 'mgrl_reward_type' );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		if ( $icon ) {
			update_term_meta( $result['term_id'], 'mgrl_icon', $icon );
		}

		wp_send_json_success( array(
			'term_id'  => $result['term_id'],
			'name'     => $name,
			'icon'     => $icon,
			'existing' => false,
		) );
	}
}
