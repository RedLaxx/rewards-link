<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGRL_Metaboxes {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_metaboxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ) );
	}

	public static function add_metaboxes() {
		foreach ( array( 'post', 'page' ) as $post_type ) {
			add_meta_box(
				'mgrl_rewards_box',
				__( 'Monopoly GO Reward Links', 'mgrl' ),
				array( __CLASS__, 'render' ),
				$post_type,
				'normal',
				'high'
			);
		}
	}

	public static function render( $post ) {
		wp_nonce_field( 'mgrl_save_cards', 'mgrl_nonce' );

		$cards         = MGRL_DB::get_for_post( $post->ID );
		$all_types     = get_terms( array( 'taxonomy' => 'mgrl_reward_type', 'hide_empty' => false ) );
		$show_updated  = get_post_meta( $post->ID, '_mgrl_show_updated', true );
		$show_updated  = ( '' === $show_updated ) ? true : ( '1' === $show_updated ); // Default on for posts that haven't been saved with this option yet.
		?>
		<div class="mgrl-metabox">
			<p class="description">
				<?php esc_html_e( 'Add each reward card below, then drop the shortcode ', 'mgrl' ); ?><code>[mgrl_rewards]</code>
				<?php esc_html_e( ' anywhere in this post\'s content to render them right there.', 'mgrl' ); ?>
			</p>

			<p class="mgrl-updated-toggle">
				<label>
					<input type="checkbox" name="mgrl_show_updated" value="1" <?php checked( $show_updated ); ?> />
					<?php esc_html_e( 'Show the "Updated" badge at the top of the reward cards on this post.', 'mgrl' ); ?>
				</label>
				<br /><span class="description"><?php esc_html_e( 'This only affects this post — it won\'t change the badge on any other post.', 'mgrl' ); ?></span>
			</p>

			<div id="mgrl-cards-rows">
				<?php if ( ! empty( $cards ) ) : ?>
					<?php foreach ( $cards as $i => $card ) : ?>
						<?php self::render_card_row( $i, $card, $all_types ); ?>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>

			<button type="button" class="button button-primary" id="mgrl-add-card"><?php esc_html_e( '+ Add Reward Card', 'mgrl' ); ?></button>
		</div>

		<script type="text/template" id="mgrl-card-row-template">
			<?php self::render_card_row( '__INDEX__', array(), $all_types ); ?>
		</script>
		<script type="text/template" id="mgrl-reward-row-template">
			<?php self::render_reward_row( '__CARD_INDEX__', '__REWARD_INDEX__', array(), $all_types ); ?>
		</script>
		<?php
	}

	private static function render_card_row( $index, $card, $all_types ) {
		$title       = isset( $card['title'] ) ? $card['title'] : '';
		$claim_url   = isset( $card['claim_url'] ) ? $card['claim_url'] : '';
		$start       = isset( $card['start_local'] ) ? $card['start_local'] : '';
		$end         = isset( $card['end_local'] ) ? $card['end_local'] : '';
		$is_new      = ! empty( $card['is_new'] );
		$title_image = isset( $card['title_image'] ) ? $card['title_image'] : '';
		$rewards     = isset( $card['rewards'] ) ? json_decode( $card['rewards'], true ) : array();
		$rewards     = is_array( $rewards ) ? $rewards : array();
		$label       = $title ? $title : __( 'New Reward Card', 'mgrl' );
		?>
		<div class="mgrl-card-row" data-index="<?php echo esc_attr( $index ); ?>">
			<div class="mgrl-card-row-head">
				<div class="mgrl-card-row-move">
					<button type="button" class="button mgrl-move-up" title="<?php esc_attr_e( 'Move up', 'mgrl' ); ?>">▲</button>
					<button type="button" class="button mgrl-move-down" title="<?php esc_attr_e( 'Move down', 'mgrl' ); ?>">▼</button>
				</div>
				<strong class="mgrl-card-row-title"><?php echo esc_html( $label ); ?></strong>
				<button type="button" class="button-link-delete mgrl-remove-card"><?php esc_html_e( 'Remove Card', 'mgrl' ); ?></button>
			</div>

			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Title', 'mgrl' ); ?></th>
					<td>
						<input type="text" class="regular-text mgrl-card-title" name="mgrl_cards[<?php echo esc_attr( $index ); ?>][title]" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php esc_attr_e( 'e.g. Free Rolls Reward Link', 'mgrl' ); ?>" required />
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Title Image', 'mgrl' ); ?></th>
					<td>
						<input type="hidden" class="mgrl-title-image-value" name="mgrl_cards[<?php echo esc_attr( $index ); ?>][title_image]" value="<?php echo esc_attr( $title_image ); ?>" />
						<button type="button" class="button mgrl-upload-icon-btn"><?php esc_html_e( 'Select Image', 'mgrl' ); ?></button>
						<button type="button" class="button mgrl-image-clear" <?php echo $title_image ? '' : 'style="display:none;"'; ?>><?php esc_html_e( 'Remove', 'mgrl' ); ?></button>
						<div class="mgrl-icon-preview">
							<?php if ( $title_image ) : ?><img src="<?php echo esc_url( $title_image ); ?>" style="max-width:60px;height:auto;display:block;margin-top:8px;" /><?php endif; ?>
						</div>
						<p class="description"><?php esc_html_e( 'Optional. Shown next to the card title, e.g. a small logo or banner.', 'mgrl' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Mark as New', 'mgrl' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="mgrl_cards[<?php echo esc_attr( $index ); ?>][is_new]" value="1" <?php checked( $is_new ); ?> />
							<?php esc_html_e( 'Show a "New" badge on this card.', 'mgrl' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Start Date & Time (GMT+1)', 'mgrl' ); ?></th>
					<td><input type="datetime-local" name="mgrl_cards[<?php echo esc_attr( $index ); ?>][start]" value="<?php echo esc_attr( $start ); ?>" /></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'End Date & Time (GMT+1)', 'mgrl' ); ?></th>
					<td>
						<input type="datetime-local" name="mgrl_cards[<?php echo esc_attr( $index ); ?>][end]" value="<?php echo esc_attr( $end ); ?>" />
						<p class="description"><?php esc_html_e( 'Optional. When set, controls the Live / Upcoming / Ended status and border color, synced to each visitor\'s own local time. Leave both dates blank for a card with no time limit — it just displays normally with no status badge.', 'mgrl' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Claim URL', 'mgrl' ); ?></th>
					<td>
						<input type="url" class="regular-text" name="mgrl_cards[<?php echo esc_attr( $index ); ?>][claim_url]" value="<?php echo esc_attr( $claim_url ); ?>" placeholder="https://" />
						<p class="description"><?php esc_html_e( 'Optional. Where the "Claim reward" button sends visitors. Leave blank and the card just won\'t show a claim button.', 'mgrl' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Rewards', 'mgrl' ); ?></th>
					<td>
						<div class="mgrl-rewards-rows" data-next-reward-index="<?php echo esc_attr( count( $rewards ) ); ?>">
							<?php foreach ( $rewards as $r_i => $r ) : ?>
								<?php self::render_reward_row( $index, $r_i, $r, $all_types ); ?>
							<?php endforeach; ?>
						</div>
						<button type="button" class="button mgrl-add-reward"><?php esc_html_e( '+ Add Reward', 'mgrl' ); ?></button>
						<p class="description"><?php esc_html_e( 'A card can carry more than one reward — e.g. Rolls + Loot Box + Loot Box.', 'mgrl' ); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	private static function render_reward_row( $card_index, $reward_index, $reward, $all_types ) {
		$type_term_id = isset( $reward['type_term_id'] ) ? (int) $reward['type_term_id'] : 0;
		$quantity     = isset( $reward['quantity'] ) ? (int) $reward['quantity'] : '';
		$image        = isset( $reward['image'] ) ? $reward['image'] : '';
		?>
		<div class="mgrl-reward-row">
			<select class="mgrl-reward-type" name="mgrl_cards[<?php echo esc_attr( $card_index ); ?>][rewards][<?php echo esc_attr( $reward_index ); ?>][type_term_id]">
				<option value=""><?php esc_html_e( '— Select a reward —', 'mgrl' ); ?></option>
				<?php foreach ( $all_types as $term ) : ?>
					<option value="<?php echo esc_attr( $term->term_id ); ?>" data-icon="<?php echo esc_attr( get_term_meta( $term->term_id, 'mgrl_icon', true ) ); ?>" <?php selected( $type_term_id, $term->term_id ); ?>>
						<?php echo esc_html( $term->name ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<input type="number" min="1" step="1" class="mgrl-reward-qty" style="width:90px;" name="mgrl_cards[<?php echo esc_attr( $card_index ); ?>][rewards][<?php echo esc_attr( $reward_index ); ?>][quantity]" value="<?php echo esc_attr( $quantity ); ?>" placeholder="<?php esc_attr_e( 'Qty', 'mgrl' ); ?>" />
			<span class="mgrl-reward-image-field">
				<input type="hidden" class="mgrl-reward-image-value" name="mgrl_cards[<?php echo esc_attr( $card_index ); ?>][rewards][<?php echo esc_attr( $reward_index ); ?>][image]" value="<?php echo esc_attr( $image ); ?>" />
				<button type="button" class="button mgrl-upload-icon-btn"><?php esc_html_e( 'Bigger Image', 'mgrl' ); ?></button>
				<button type="button" class="button mgrl-image-clear" <?php echo $image ? '' : 'style="display:none;"'; ?>><?php esc_html_e( 'Remove', 'mgrl' ); ?></button>
				<span class="mgrl-icon-preview"><?php if ( $image ) : ?><img src="<?php echo esc_url( $image ); ?>" style="max-width:50px;height:auto;display:block;margin-top:8px;" /><?php endif; ?></span>
			</span>
			<button type="button" class="button mgrl-add-type-toggle"><?php esc_html_e( '+ New Reward', 'mgrl' ); ?></button>
			<button type="button" class="button-link-delete mgrl-remove-reward"><?php esc_html_e( 'Remove', 'mgrl' ); ?></button>
			<p class="description mgrl-reward-image-hint"><?php esc_html_e( 'Bigger Image is optional — when set, this reward displays as a larger photo card instead of a small icon pill.', 'mgrl' ); ?></p>
			<div class="mgrl-add-type-row" style="display:none;">
				<input type="text" class="mgrl-new-type-name" placeholder="<?php esc_attr_e( 'New reward name…', 'mgrl' ); ?>" />
				<input type="hidden" class="mgrl-new-type-icon" value="" />
				<button type="button" class="button mgrl-upload-icon-btn"><?php esc_html_e( 'Icon', 'mgrl' ); ?></button>
				<span class="mgrl-icon-preview"></span>
				<button type="button" class="button button-secondary mgrl-add-type-save"><?php esc_html_e( 'Save', 'mgrl' ); ?></button>
				<span class="spinner" style="float:none;"></span>
			</div>
		</div>
		<?php
	}

	public static function save( $post_id ) {
		if ( ! isset( $_POST['mgrl_nonce'] ) || ! wp_verify_nonce( $_POST['mgrl_nonce'], 'mgrl_save_cards' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		$posted = isset( $_POST['mgrl_cards'] ) && is_array( $_POST['mgrl_cards'] ) ? wp_unslash( $_POST['mgrl_cards'] ) : array();
		$cards  = array();

		foreach ( $posted as $row ) {
			$title = isset( $row['title'] ) ? sanitize_text_field( $row['title'] ) : '';
			$start = isset( $row['start'] ) ? sanitize_text_field( $row['start'] ) : '';
			$end   = isset( $row['end'] ) ? sanitize_text_field( $row['end'] ) : '';

			// Skip fully empty rows (e.g. a row added then left untouched).
			if ( ! $title && ! $start && ! $end ) {
				continue;
			}

			$rewards = array();
			if ( isset( $row['rewards'] ) && is_array( $row['rewards'] ) ) {
				foreach ( $row['rewards'] as $reward_row ) {
					$type_term_id = isset( $reward_row['type_term_id'] ) ? (int) $reward_row['type_term_id'] : 0;
					$quantity     = isset( $reward_row['quantity'] ) ? absint( $reward_row['quantity'] ) : 0;
					if ( ! $type_term_id || ! $quantity ) {
						continue;
					}
					$term = get_term( $type_term_id, 'mgrl_reward_type' );
					$rewards[] = array(
						'type_term_id' => $type_term_id,
						'name'         => ( $term && ! is_wp_error( $term ) ) ? $term->name : '',
						'icon'         => ( $term && ! is_wp_error( $term ) ) ? get_term_meta( $type_term_id, 'mgrl_icon', true ) : '',
						'image'        => isset( $reward_row['image'] ) ? esc_url_raw( $reward_row['image'] ) : '',
						'quantity'     => $quantity,
					);
				}
			}

			$cards[] = array(
				'title'       => $title,
				'claim_url'   => isset( $row['claim_url'] ) ? esc_url_raw( $row['claim_url'] ) : '',
				'start'       => $start,
				'end'         => $end,
				'is_new'      => ! empty( $row['is_new'] ),
				'title_image' => isset( $row['title_image'] ) ? esc_url_raw( $row['title_image'] ) : '',
				'rewards'     => $rewards,
			);
		}

		MGRL_DB::save_for_post( $post_id, $cards );

		update_post_meta( $post_id, '_mgrl_show_updated', isset( $_POST['mgrl_show_updated'] ) ? '1' : '0' );
	}
}
