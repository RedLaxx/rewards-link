<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGRL_Settings {

	const SLUG = 'mgrl-settings';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	public static function menu() {
		add_menu_page(
			__( 'Monopoly GO Reward Links', 'mgrl' ),
			__( 'Reward Links', 'mgrl' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' ),
			'dashicons-awards',
			26
		);

		add_submenu_page(
			self::SLUG,
			__( 'Settings', 'mgrl' ),
			__( 'Settings', 'mgrl' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Reward Types', 'mgrl' ),
			__( 'Reward Types', 'mgrl' ),
			'manage_options',
			'edit-tags.php?taxonomy=mgrl_reward_type&post_type=post'
		);
	}

	/** Eight quick-start presets — the original three plus five more, all built from the same set of CSS variables. */
	public static function templates() {
		return array(
			'default'  => __( 'Board Green (default)', 'mgrl' ),
			'midnight' => __( 'Midnight Gold', 'mgrl' ),
			'light'    => __( 'Classic Light', 'mgrl' ),
			'neon'     => __( 'Neon Arcade', 'mgrl' ),
			'sunset'   => __( 'Sunset Pop', 'mgrl' ),
			'ocean'    => __( 'Ocean Breeze', 'mgrl' ),
			'royal'    => __( 'Royal Purple', 'mgrl' ),
			'mono'     => __( 'Minimal Mono', 'mgrl' ),
		);
	}

	public static function sizes() {
		return array(
			'compact' => __( 'Compact', 'mgrl' ),
			'small'   => __( 'Small', 'mgrl' ),
			'medium'  => __( 'Medium (default)', 'mgrl' ),
			'large'   => __( 'Large', 'mgrl' ),
			'xl'      => __( 'Extra Large', 'mgrl' ),
		);
	}

	public static function shapes() {
		return array(
			'rounded' => __( 'Rounded (default)', 'mgrl' ),
			'sharp'   => __( 'Sharp Corners', 'mgrl' ),
			'pill'    => __( 'Extra Rounded / Pill', 'mgrl' ),
		);
	}

	public static function sanitize_template( $value ) {
		return array_key_exists( $value, self::templates() ) ? $value : 'default';
	}

	public static function sanitize_size( $value ) {
		return array_key_exists( $value, self::sizes() ) ? $value : 'medium';
	}

	public static function sanitize_shape( $value ) {
		return array_key_exists( $value, self::shapes() ) ? $value : 'rounded';
	}

	public static function register_settings() {
		register_setting( 'mgrl_settings_group', 'mgrl_card_template', array(
			'type'              => 'string',
			'default'           => 'default',
			'sanitize_callback' => array( __CLASS__, 'sanitize_template' ),
		) );

		register_setting( 'mgrl_settings_group', 'mgrl_title_color', array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'sanitize_hex_color', // Empty string passes through, falls back to the template's own title color.
		) );

		register_setting( 'mgrl_settings_group', 'mgrl_tile_size', array(
			'type'              => 'string',
			'default'           => 'medium',
			'sanitize_callback' => array( __CLASS__, 'sanitize_size' ),
		) );

		register_setting( 'mgrl_settings_group', 'mgrl_card_shape', array(
			'type'              => 'string',
			'default'           => 'rounded',
			'sanitize_callback' => array( __CLASS__, 'sanitize_shape' ),
		) );

		register_setting( 'mgrl_settings_group', 'mgrl_claim_button_text', array(
			'type'              => 'string',
			'default'           => 'Claim reward',
			'sanitize_callback' => 'sanitize_text_field',
		) );

		register_setting( 'mgrl_settings_group', 'mgrl_disable_claim_on_ended', array(
			'type'              => 'boolean',
			'default'           => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
		) );
	}

	public static function enqueue( $hook ) {
		if ( strpos( $hook, self::SLUG ) === false ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){ $(".mgrl-color-picker").wpColorPicker(); });' );
	}

	public static function render_page() {
		$template   = get_option( 'mgrl_card_template', 'default' );
		$size       = get_option( 'mgrl_tile_size', 'medium' );
		$shape      = get_option( 'mgrl_card_shape', 'rounded' );
		$claim_text = get_option( 'mgrl_claim_button_text', 'Claim reward' );
		$disable_on_ended = get_option( 'mgrl_disable_claim_on_ended', true );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Monopoly GO Reward Links — Settings', 'mgrl' ); ?></h1>
			<p>
				<?php esc_html_e( 'Reward cards are added directly inside each post or page you\'re editing — look for the "Monopoly GO Reward Links" box below the content editor. This page covers appearance and a few site-wide options.', 'mgrl' ); ?>
			</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'mgrl_settings_group' ); ?>
				<table class="form-table">
					<tr>
						<th scope="row"><label for="mgrl_card_template"><?php esc_html_e( 'Card Template', 'mgrl' ); ?></label></th>
						<td>
							<select id="mgrl_card_template" name="mgrl_card_template">
								<?php foreach ( self::templates() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $template, $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'A quick-start color scheme for every reward card.', 'mgrl' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="mgrl_title_color"><?php esc_html_e( 'Card Title Color', 'mgrl' ); ?></label></th>
						<td>
							<input type="text" id="mgrl_title_color" name="mgrl_title_color" class="mgrl-color-picker" value="<?php echo esc_attr( get_option( 'mgrl_title_color', '' ) ); ?>" data-default-color="" />
							<p class="description"><?php esc_html_e( 'Optional. Overrides the card title color from the template above. Clear it to go back to the template default.', 'mgrl' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="mgrl_tile_size"><?php esc_html_e( 'Tile Size', 'mgrl' ); ?></label></th>
						<td>
							<select id="mgrl_tile_size" name="mgrl_tile_size">
								<?php foreach ( self::sizes() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $size, $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Controls padding, image size, and text size for every reward card.', 'mgrl' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="mgrl_card_shape"><?php esc_html_e( 'Card Shape', 'mgrl' ); ?></label></th>
						<td>
							<select id="mgrl_card_shape" name="mgrl_card_shape">
								<?php foreach ( self::shapes() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $shape, $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Controls corner rounding on the card, buttons, and reward pills.', 'mgrl' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="mgrl_claim_button_text"><?php esc_html_e( 'Claim Button Text', 'mgrl' ); ?></label></th>
						<td>
							<input type="text" id="mgrl_claim_button_text" name="mgrl_claim_button_text" value="<?php echo esc_attr( $claim_text ); ?>" class="regular-text" />
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'When a Card Ends', 'mgrl' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="mgrl_disable_claim_on_ended" value="1" <?php checked( $disable_on_ended ); ?> />
								<?php esc_html_e( 'Gray out and disable the Claim button once a card\'s availability window has ended.', 'mgrl' ); ?>
							</label>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<hr />

			<h2><?php esc_html_e( 'Reward Types', 'mgrl' ); ?></h2>
			<p class="description">
				<?php
				printf(
					/* translators: %s: link to the Reward Types screen */
					esc_html__( 'Add, rename, or set the icon for any reusable reward type under %s. You can also add a new one on the fly from inside any reward card\'s "+ New Reward" button.', 'mgrl' ),
					'<a href="' . esc_url( admin_url( 'edit-tags.php?taxonomy=mgrl_reward_type&post_type=post' ) ) . '">' . esc_html__( 'Reward Links → Reward Types', 'mgrl' ) . '</a>'
				);
				?>
			</p>
		</div>
		<?php
	}
}
