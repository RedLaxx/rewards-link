<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGRL_Shortcodes {

	public static function init() {
		add_shortcode( 'mgrl_rewards', array( __CLASS__, 'render' ) );
	}

	/**
	 * [mgrl_rewards] — renders the reward cards added (in the post editor
	 * box) to whichever post/page this shortcode is placed inside. Pass
	 * post_id="123" to pull another post's cards instead of the current one.
	 */
	public static function render( $atts ) {
		$atts    = shortcode_atts( array( 'post_id' => 0 ), $atts );
		$post_id = (int) $atts['post_id'];
		if ( ! $post_id ) {
			$post_id = get_the_ID();
		}
		if ( ! $post_id ) {
			return '';
		}

		$rows = MGRL_DB::get_for_post( $post_id );
		if ( empty( $rows ) ) {
			return '<p class="mgrl-empty">' . esc_html__( 'No reward links added to this post yet.', 'mgrl' ) . '</p>';
		}

		$last_updated = MGRL_DB::get_last_updated_for_post( $post_id );
		$show_updated = get_post_meta( $post_id, '_mgrl_show_updated', true );
		$show_updated = ( '' === $show_updated ) ? true : ( '1' === $show_updated );

		ob_start();
		?>
		<div class="mgrl-wrap <?php echo esc_attr( self::wrapper_classes() ); ?>" <?php echo self::wrapper_style(); ?>>
			<?php if ( $show_updated && $last_updated ) : ?>
				<div class="mgrl-updated" data-mgrl-updated="<?php echo esc_attr( str_replace( ' ', 'T', $last_updated ) . 'Z' ); ?>">
					<span class="mgrl-updated-dot"></span>
					<?php esc_html_e( 'Updated', 'mgrl' ); ?> <span data-mgrl-updated-text></span>
				</div>
			<?php endif; ?>

			<div class="mgrl-cards">
				<?php foreach ( $rows as $row ) : self::render_card( $row ); endforeach; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/** "mgrl-theme-{template} mgrl-size-{size} mgrl-shape-{shape}" classes, driven by Settings. */
	private static function wrapper_classes() {
		$template = get_option( 'mgrl_card_template', 'default' );
		$size     = get_option( 'mgrl_tile_size', 'medium' );
		$shape    = get_option( 'mgrl_card_shape', 'rounded' );
		return 'mgrl-theme-' . sanitize_html_class( $template ) . ' mgrl-size-' . sanitize_html_class( $size ) . ' mgrl-shape-' . sanitize_html_class( $shape );
	}

	/** Inline --mgrl-title-color custom property, only when an override is set. */
	private static function wrapper_style() {
		$color = get_option( 'mgrl_title_color', '' );
		if ( ! $color ) {
			return '';
		}
		return 'style="--mgrl-title-color: ' . esc_attr( $color ) . ';"';
	}

	private static function render_card( $row ) {
		$rewards = json_decode( $row['rewards'], true );
		$rewards = is_array( $rewards ) ? $rewards : array();

		$has_dates   = ! empty( $row['start_utc'] ) && ! empty( $row['end_utc'] );
		$start_utc   = $has_dates ? str_replace( ' ', 'T', $row['start_utc'] ) . 'Z' : '';
		$end_utc     = $has_dates ? str_replace( ' ', 'T', $row['end_utc'] ) . 'Z' : '';
		$is_new      = ! empty( $row['is_new'] );
		$title_image = ! empty( $row['title_image'] ) ? $row['title_image'] : '';

		$card_classes = 'mgrl-card';
		if ( ! $has_dates ) { $card_classes .= ' mgrl-no-dates'; }
		if ( $has_dates ) { $card_classes .= ' mgrl-has-status'; }
		if ( $is_new ) { $card_classes .= ' mgrl-has-new'; }
		?>
		<div class="<?php echo esc_attr( $card_classes ); ?>"<?php if ( $has_dates ) : ?> data-mgrl-card data-start="<?php echo esc_attr( $start_utc ); ?>" data-end="<?php echo esc_attr( $end_utc ); ?>"<?php endif; ?>>
			<div class="mgrl-card-bar"></div>
			<?php if ( $has_dates ) : ?>
				<div class="mgrl-card-status" data-mgrl-status></div>
			<?php endif; ?>
			<?php if ( $is_new ) : ?>
				<div class="mgrl-new-badge"><?php esc_html_e( 'New', 'mgrl' ); ?></div>
			<?php endif; ?>
			<div class="mgrl-card-body">
				<div class="mgrl-card-title-row">
					<?php if ( $title_image ) : ?>
						<img class="mgrl-card-title-image" src="<?php echo esc_url( $title_image ); ?>" alt="" />
					<?php endif; ?>
					<h3 class="mgrl-card-title"><?php echo esc_html( $row['title'] ); ?></h3>
				</div>

				<?php if ( ! empty( $rewards ) ) : ?>
					<div class="mgrl-reward-pills">
						<?php foreach ( $rewards as $r ) : ?>
							<?php if ( ! empty( $r['image'] ) ) : ?>
								<span class="mgrl-reward-big">
									<img class="mgrl-reward-big-img" src="<?php echo esc_url( $r['image'] ); ?>" alt="" />
									<span class="mgrl-reward-big-info">
										<strong><?php echo esc_html( $r['quantity'] ); ?>×</strong>
										<span><?php echo esc_html( $r['name'] ); ?></span>
									</span>
								</span>
							<?php else : ?>
								<span class="mgrl-reward-pill">
									<?php if ( ! empty( $r['icon'] ) ) : ?>
										<img src="<?php echo esc_url( $r['icon'] ); ?>" alt="" />
									<?php endif; ?>
									<strong><?php echo esc_html( $r['quantity'] ); ?>×</strong>
									<span><?php echo esc_html( $r['name'] ); ?></span>
								</span>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<?php if ( $has_dates ) : ?>
					<div class="mgrl-availability">
						<?php esc_html_e( 'Available', 'mgrl' ); ?> <span data-mgrl-time></span>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $row['claim_url'] ) ) : ?>
					<a class="mgrl-claim-btn" href="<?php echo esc_url( $row['claim_url'] ); ?>" target="_blank" rel="noopener noreferrer" data-mgrl-claim data-disable-on-ended="<?php echo get_option( 'mgrl_disable_claim_on_ended', true ) ? '1' : '0'; ?>">
						<?php echo esc_html( get_option( 'mgrl_claim_button_text', 'Claim reward' ) ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
