<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Reward cards live per-post (added right in the post editor), stored here
 * so display logic stays fast and simple. Each card's `rewards` column is a
 * small JSON array — the multiple reward pills a single card can carry.
 */
class MGRL_DB {

	const SITE_OFFSET = '+01:00'; // Admin-entered times are always treated as this fixed offset (matches the Events plugin).

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'mgrl_cards';
	}

	/** Runs on every load; creates/repairs the table if the version marker is missing or stale. */
	public static function maybe_install() {
		if ( get_option( 'mgrl_db_version' ) === MGRL_VERSION ) {
			return;
		}
		self::install();
		update_option( 'mgrl_db_version', MGRL_VERSION );
	}

	public static function install() {
		global $wpdb;
		$table_name      = self::table();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id BIGINT UNSIGNED NOT NULL,
			sort_order INT NOT NULL DEFAULT 0,
			title VARCHAR(191) NOT NULL DEFAULT '',
			claim_url VARCHAR(500) NOT NULL DEFAULT '',
			start_local VARCHAR(20) NOT NULL DEFAULT '',
			start_utc DATETIME NULL DEFAULT NULL,
			end_local VARCHAR(20) NOT NULL DEFAULT '',
			end_utc DATETIME NULL DEFAULT NULL,
			is_new TINYINT(1) NOT NULL DEFAULT 0,
			title_image VARCHAR(500) NOT NULL DEFAULT '',
			rewards LONGTEXT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY post_id (post_id),
			KEY start_utc (start_utc),
			KEY end_utc (end_utc)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		// dbDelta doesn't reliably flip an existing NOT NULL column to NULL on
		// upgrades, so force it explicitly — safe to re-run, no data loss.
		$wpdb->query( "ALTER TABLE {$table_name} MODIFY start_utc DATETIME NULL DEFAULT NULL" );
		$wpdb->query( "ALTER TABLE {$table_name} MODIFY end_utc DATETIME NULL DEFAULT NULL" );
	}

	/** Convert a "Y-m-d\TH:i" string (always GMT+1) to a MySQL UTC datetime. */
	public static function to_utc_mysql( $local_datetime ) {
		if ( empty( $local_datetime ) ) {
			return null;
		}
		try {
			$dt = new DateTime( str_replace( 'T', ' ', $local_datetime ), new DateTimeZone( self::SITE_OFFSET ) );
			$dt->setTimezone( new DateTimeZone( 'UTC' ) );
			return $dt->format( 'Y-m-d H:i:s' );
		} catch ( Exception $e ) {
			return null;
		}
	}

	/** All reward cards belonging to a single post, in the order the admin arranged them. */
	public static function get_for_post( $post_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM " . self::table() . " WHERE post_id = %d ORDER BY sort_order ASC, id ASC",
			$post_id
		), ARRAY_A );
		return $rows ? $rows : array();
	}

	/** Most recent updated_at among a post's cards (UTC MySQL string), for the "Updated" badge. Null if there are none. */
	public static function get_last_updated_for_post( $post_id ) {
		global $wpdb;
		return $wpdb->get_var( $wpdb->prepare(
			"SELECT MAX(updated_at) FROM " . self::table() . " WHERE post_id = %d",
			$post_id
		) );
	}

	/** Replace all reward cards for a post with a fresh set (called on save_post). */
	public static function save_for_post( $post_id, $cards ) {
		global $wpdb;
		$table = self::table();

		$wpdb->delete( $table, array( 'post_id' => $post_id ), array( '%d' ) );

		$now = gmdate( 'Y-m-d H:i:s' );

		foreach ( $cards as $i => $card ) {
			$start_utc = self::to_utc_mysql( $card['start'] ); // null when no date was entered — that's fine now.
			$end_utc   = self::to_utc_mysql( $card['end'] );

			$wpdb->insert( $table, array(
				'post_id'     => $post_id,
				'sort_order'  => $i,
				'title'       => $card['title'],
				'claim_url'   => $card['claim_url'],
				'start_local' => $card['start'],
				'start_utc'   => $start_utc,
				'end_local'   => $card['end'],
				'end_utc'     => $end_utc,
				'is_new'      => $card['is_new'] ? 1 : 0,
				'title_image' => $card['title_image'],
				'rewards'     => wp_json_encode( $card['rewards'] ),
				'updated_at'  => $now,
			), array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ) );
		}
	}
}
