<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGRL_Assets {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'frontend' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin' ) );
	}

	public static function frontend() {
		if ( is_admin() ) {
			return;
		}
		wp_enqueue_style( 'mgrl-frontend', MGRL_URL . 'assets/css/frontend.css', array(), MGRL_VERSION );
		wp_enqueue_script( 'mgrl-frontend', MGRL_URL . 'assets/js/frontend.js', array(), MGRL_VERSION, true );
	}

	public static function admin( $hook ) {
		$load = false;

		if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			global $post_type;
			$load = in_array( $post_type, array( 'post', 'page' ), true );
		} elseif ( 'edit-tags.php' === $hook || 'term.php' === $hook ) {
			$load = isset( $_GET['taxonomy'] ) && 'mgrl_reward_type' === $_GET['taxonomy'];
		}

		if ( ! $load ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_style( 'mgrl-admin', MGRL_URL . 'assets/css/admin.css', array(), MGRL_VERSION );
		wp_enqueue_script( 'mgrl-admin', MGRL_URL . 'assets/js/admin.js', array( 'jquery' ), MGRL_VERSION, true );
		wp_localize_script( 'mgrl-admin', 'MGRL_Admin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'mgrl_admin_nonce' ),
		) );
	}
}
