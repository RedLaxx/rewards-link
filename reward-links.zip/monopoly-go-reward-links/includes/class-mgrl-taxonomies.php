<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGRL_Taxonomies {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_taxonomy' ) );

		add_action( 'mgrl_reward_type_add_form_fields', array( __CLASS__, 'add_icon_field' ) );
		add_action( 'mgrl_reward_type_edit_form_fields', array( __CLASS__, 'edit_icon_field' ) );
		add_action( 'created_mgrl_reward_type', array( __CLASS__, 'save_icon_field' ) );
		add_action( 'edited_mgrl_reward_type', array( __CLASS__, 'save_icon_field' ) );
	}

	public static function register_taxonomy() {
		register_taxonomy(
			'mgrl_reward_type',
			array( 'post', 'page' ),
			array(
				'labels' => array(
					'name'          => __( 'Reward Types', 'mgrl' ),
					'singular_name' => __( 'Reward Type', 'mgrl' ),
					'menu_name'     => __( 'Reward Types', 'mgrl' ),
					'add_new_item'  => __( 'Add New Reward Type', 'mgrl' ),
					'edit_item'     => __( 'Edit Reward Type', 'mgrl' ),
				),
				'hierarchical'      => false,
				'public'            => false,
				'show_ui'           => true,
				'show_admin_column' => false,
				'show_in_rest'      => false,
				'meta_box_cb'       => false, // Each reward item picks its own type inside the card repeater, not via WP's default box.
			)
		);
	}

	public static function add_icon_field() {
		?>
		<div class="form-field">
			<label for="mgrl-term-icon"><?php esc_html_e( 'Icon', 'mgrl' ); ?></label>
			<input type="hidden" id="mgrl-term-icon" name="mgrl_term_icon" value="" />
			<button type="button" class="button mgrl-upload-icon-btn"><?php esc_html_e( 'Select Icon', 'mgrl' ); ?></button>
			<div class="mgrl-icon-preview"></div>
			<p><?php esc_html_e( 'Shown on every reward pill using this type, e.g. the dice icon for "Rolls".', 'mgrl' ); ?></p>
		</div>
		<?php
	}

	public static function edit_icon_field( $term ) {
		$icon = get_term_meta( $term->term_id, 'mgrl_icon', true );
		?>
		<tr class="form-field">
			<th scope="row"><label for="mgrl-term-icon"><?php esc_html_e( 'Icon', 'mgrl' ); ?></label></th>
			<td>
				<input type="hidden" id="mgrl-term-icon" name="mgrl_term_icon" value="<?php echo esc_attr( $icon ); ?>" />
				<button type="button" class="button mgrl-upload-icon-btn"><?php esc_html_e( 'Select Icon', 'mgrl' ); ?></button>
				<div class="mgrl-icon-preview">
					<?php if ( $icon ) : ?>
						<img src="<?php echo esc_url( $icon ); ?>" style="max-width:50px;height:auto;display:block;margin-top:8px;" />
					<?php endif; ?>
				</div>
			</td>
		</tr>
		<?php
	}

	public static function save_icon_field( $term_id ) {
		if ( isset( $_POST['mgrl_term_icon'] ) ) {
			update_term_meta( $term_id, 'mgrl_icon', esc_url_raw( wp_unslash( $_POST['mgrl_term_icon'] ) ) );
		}
	}
}
