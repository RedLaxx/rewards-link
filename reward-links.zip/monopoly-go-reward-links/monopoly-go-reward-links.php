<?php
/**
 * Plugin Name: Monopoly GO Reward Links
 * Plugin URI:  https://example.com/monopoly-go-reward-links
 * Description: Add "Free Dice Links" reward cards directly inside the post editor — title, multiple rewards (each with its own icon), an availability window with live/upcoming/ended status synced to each visitor's local time, and a claim button. Place them anywhere with a shortcode.
 * Version:     1.4.0
 * Author:      Your Site
 * Text Domain: mgrl
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'MGRL_VERSION', '1.4.0' );
define( 'MGRL_PATH', plugin_dir_path( __FILE__ ) );
define( 'MGRL_URL', plugin_dir_url( __FILE__ ) );

require_once MGRL_PATH . 'includes/class-mgrl-db.php';
require_once MGRL_PATH . 'includes/class-mgrl-taxonomies.php';
require_once MGRL_PATH . 'includes/class-mgrl-metaboxes.php';
require_once MGRL_PATH . 'includes/class-mgrl-ajax.php';
require_once MGRL_PATH . 'includes/class-mgrl-shortcodes.php';
require_once MGRL_PATH . 'includes/class-mgrl-assets.php';
require_once MGRL_PATH . 'includes/class-mgrl-settings.php';

/**
 * Core plugin bootstrap.
 */
final class Monopoly_GO_Reward_Links {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		MGRL_DB::maybe_install();

		MGRL_Taxonomies::init();
		MGRL_Metaboxes::init();
		MGRL_Ajax::init();
		MGRL_Shortcodes::init();
		MGRL_Assets::init();
		MGRL_Settings::init();

		register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );
	}

	public static function activate() {
		MGRL_DB::install();
		MGRL_Taxonomies::register_taxonomy();
		flush_rewrite_rules();
	}
}

Monopoly_GO_Reward_Links::instance();
