=== Monopoly GO Events ===
Version: 2.4.0

== ⚠ BREAKING CHANGE in v2.4.0 ==

These shortcodes have been removed and will no longer render —
any post using them will show the literal bracket text instead:
  [mge_events]
  [mge_todays_events]
  [mge_events_by_category]
  [mge_milestone_events]  (the old hardcoded version)
  [mge_tournament_events] (the old hardcoded version)

Go through your posts and swap them for the new per-category
shortcodes below. [mge_live_ticker] is unaffected.

== What's new in v2.4.0 ==

Every category now gets its OWN shortcode automatically — including
any custom category you add later, no code changes needed:

* Flash Events        -> [mge_flash_events]
* Competitions         -> [mge_competitions]
* Milestone Events     -> [mge_milestone_events]
* Tournaments          -> [mge_tournaments]
* (any category you add) -> generated the same way

Full current list (in case you've renamed anything) is always shown
under MGO Events → Settings.

Each one is scoped to the post it's placed in: it only shows events
that were added to THAT post and set to that category. It never
pulls in events from other posts — that behavior (pulling from
everywhere) is now exclusive to [mge_live_ticker], which is
unchanged and still only shows homepage-flagged, currently-live
events from across the whole site.

Inside the post editor, each event's Category field now shows the
exact shortcode for whatever category is selected, right there —
no need to look it up separately.

== v2.3.0 (removed in v2.4.0) ==

Introduced [mge_events_by_category], [mge_milestone_events], and
[mge_tournament_events] as site-wide, hardcoded-category shortcodes.
Superseded by the fully dynamic, post-scoped system above.

== What's new in v2.3.0 ==

New shortcodes that pull events by category, from ANY post site-wide
(not just the current one) — soonest-starting first:

* [mge_milestone_events] — every event categorized "Milestone Events".
* [mge_tournament_events] — every event categorized "Tournaments".
* [mge_events_by_category category="Flash Events"] — the general-
  purpose version; works with any category, including ones you've
  renamed or added yourself. Matches by exact name, or by slug/ID if
  you prefer, e.g. category="milestone-events" or category="12".
  Add limit="10" to any of these to cap how many show.

If you've renamed the "Milestone Events" or "Tournaments" categories,
[mge_milestone_events] and [mge_tournament_events] will stop finding
matches (since they look for those exact names by default) — pass
category="Your New Name" to override, e.g.
[mge_milestone_events category="Progress Events"].

== v2.2.1 — bug fix ==

Fixed: the live time-sync script wasn't loading on pages where the
shortcode was placed somewhere other than a normal post/page content
area — a widget, a page-builder (Elementor/Divi/etc.) element, or a
template part. Those don't store the shortcode in the place the
plugin was checking, so the styling and syncing script silently
never loaded there, leaving the time blank/static.

Fix: the plugin now simply loads its (small) CSS/JS on every
front-end page, rather than trying to detect where the shortcode
is. This guarantees the live time sync and status borders work no
matter where you've placed [mge_events] or [mge_live_ticker].

== What's new in v2.2.0 ==

New appearance controls under MGO Events → Settings:

* Card Template — a quick-start color scheme: Board Green (default),
  Midnight Gold, or Classic Light. Applies to every card, the grid,
  and the homepage ticker.
* Event Title Color — an optional color picker that overrides the
  event name color from whichever template you picked. Clear it to
  fall back to the template's own color.
* Tile Size — Small / Medium / Large. Controls padding, icon size,
  and text size for every card, including the ticker.

These apply instantly to both [mge_events] and [mge_live_ticker]
everywhere they're used — no need to touch anything per-post.

== What's new in v2.1.0 ==

* Added an optional Duration field per event — a number plus a unit
  (Minutes / Hours / Days), e.g. "3 Days". It's purely a label shown
  on the card ("Duration: 3 Days") and does not affect the
  live/upcoming/ended status, which is still driven entirely by the
  Start/End Date & Time fields. Leave the number blank and the
  Duration label won't display at all.
* Updating from an older version will add the new columns
  automatically the next time any page loads — no manual step
  needed (see "Self-healing database" below).

== Self-healing database ==

The plugin stores its version number in an option and compares it on
every load. If they don't match (e.g. after uploading updated plugin
files without deactivating first), it re-runs its table setup, which
safely adds any new columns without touching existing data.

== What changed in v2 ==

Events are no longer managed on a separate admin screen. Instead:

* Open any Post or Page in wp-admin — you'll see a "Monopoly GO Events"
  box right below the content editor.
* Click "+ Add Event" to add as many events as you like to that post
  (name, category, start/end time, icon, flash toggle, rewards,
  homepage-ticker toggle) — all edited in place.
* Drop the shortcode [mge_events] anywhere in that post's content —
  in the middle of a paragraph, at the top, wherever — and it renders
  exactly the events you added, right there.

== Shortcodes ==

[mge_events]
  Renders the events that were added (in the post editor box) to
  whichever post/page this shortcode is placed inside. Place it
  anywhere in the content — the events render at that exact spot.
  Optionally: [mge_events post_id="123"] to pull another post's
  events instead of the current one.

[mge_todays_events]
  Alias of [mge_events], kept for backward compatibility with v1.

[mge_live_ticker]
  Compact horizontal-scroll strip pulling from EVERY post/page on the
  site — any event anywhere that's flagged "Homepage Ticker" and is
  currently within its live window. Add this to your homepage.

== Categories & Event Names ==

Both are still fully editable, now under a dedicated "MGO Events" menu
in the admin sidebar:
* MGO Events → Categories — rename/add/delete (Flash Events,
  Competitions, Milestone Events, Tournaments ship as defaults).
* MGO Events → Event Names — the reusable, saved list of event
  names. You can also add a new one on the fly from inside the
  event row itself ("+ Add New Name") without leaving the post editor.

== How live time sync works ==

Times are entered by the admin in a fixed GMT+1 (2:00pm entered =
2:00pm GMT+1, regardless of what timezone is configured under
Settings → General). On the front end, each card's start/end time is
converted from GMT+1 to UTC. JavaScript in the visitor's browser
compares that UTC time against the visitor's own device clock and
displays it in their local time — so the displayed time and the
live/upcoming/ended border color are always correct for whoever is
looking at the page, no matter their timezone. Status is rechecked
every 15 seconds so a card flips from "Upcoming" to "Live" (or "Live"
to "Ended") without a page reload.

== Install ==

1. Plugins → Add New → Upload Plugin → select the zip → Activate.
2. Check MGO Events → Categories to review the starter categories.
3. Edit any post/page, scroll to the "Monopoly GO Events" box, add
   your first event, and insert [mge_events] into the content.
4. Add [mge_live_ticker] to your homepage template or a block there.

This is v2 — built to be extended. Good next additions: countdown
timers on upcoming cards, per-category color overrides, and a native
block version of [mge_events] with live preview in the editor canvas.
