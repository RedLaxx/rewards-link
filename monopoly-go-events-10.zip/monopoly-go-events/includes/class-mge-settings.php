<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGE_Settings {

	const SLUG = 'mge-settings';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	public static function menu() {
		add_menu_page(
			__( 'Monopoly GO Events', 'mge' ),
			__( 'MGO Events', 'mge' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' ),
			'dashicons-tickets-alt',
			25
		);

		add_submenu_page(
			self::SLUG,
			__( 'Settings', 'mge' ),
			__( 'Settings', 'mge' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' )
		);

		add_submenu_page(
			self::SLUG,
			__( 'Event Categories', 'mge' ),
			__( 'Categories', 'mge' ),
			'manage_options',
			'edit-tags.php?taxonomy=mge_category&post_type=post'
		);

		add_submenu_page(
			self::SLUG,
			__( 'Event Names', 'mge' ),
			__( 'Event Names', 'mge' ),
			'manage_options',
			'edit-tags.php?taxonomy=mge_event_name&post_type=post'
		);
	}

	/** The templates offered as quick-start presets. */
	public static function templates() {
		return array(
			'default'  => __( 'Board Green (default)', 'mge' ),
			'midnight' => __( 'Midnight Gold', 'mge' ),
			'light'    => __( 'Classic Light', 'mge' ),
		);
	}

	public static function sizes() {
		return array(
			'small'  => __( 'Small', 'mge' ),
			'medium' => __( 'Medium (default)', 'mge' ),
			'large'  => __( 'Large', 'mge' ),
		);
	}

	public static function sanitize_template( $value ) {
		return array_key_exists( $value, self::templates() ) ? $value : 'default';
	}

	public static function sanitize_size( $value ) {
		return array_key_exists( $value, self::sizes() ) ? $value : 'medium';
	}

	public static function register_settings() {
		register_setting( 'mge_settings_group', 'mge_ticker_limit', array(
			'type'              => 'integer',
			'default'           => 5,
			'sanitize_callback' => 'absint',
		) );

		register_setting( 'mge_settings_group', 'mge_card_template', array(
			'type'              => 'string',
			'default'           => 'default',
			'sanitize_callback' => array( __CLASS__, 'sanitize_template' ),
		) );

		register_setting( 'mge_settings_group', 'mge_title_color', array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'sanitize_hex_color', // Empty string passes through, falls back to the template's own title color.
		) );

		register_setting( 'mge_settings_group', 'mge_tile_size', array(
			'type'              => 'string',
			'default'           => 'medium',
			'sanitize_callback' => array( __CLASS__, 'sanitize_size' ),
		) );
	}

	public static function enqueue( $hook ) {
		if ( strpos( $hook, self::SLUG ) === false ) {
			return;
		}
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){ $(".mge-color-picker").wpColorPicker(); });' );
	}

	public static function render_page() {
		$template = get_option( 'mge_card_template', 'default' );
		$size     = get_option( 'mge_tile_size', 'medium' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Monopoly GO Events — Settings', 'mge' ); ?></h1>
			<p>
				<?php esc_html_e( 'Events themselves are added directly inside each post or page you\'re editing — look for the "Monopoly GO Events" box below the content editor. This page covers site-wide options and appearance.', 'mge' ); ?>
			</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'mge_settings_group' ); ?>
				<table class="form-table">
					<tr>
						<th scope="row"><label for="mge_ticker_limit"><?php esc_html_e( 'Homepage Ticker Limit', 'mge' ); ?></label></th>
						<td>
							<input type="number" min="1" max="20" id="mge_ticker_limit" name="mge_ticker_limit" value="<?php echo esc_attr( get_option( 'mge_ticker_limit', 5 ) ); ?>" />
							<p class="description"><?php esc_html_e( 'Max number of cards shown in the homepage live ticker.', 'mge' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="mge_card_template"><?php esc_html_e( 'Card Template', 'mge' ); ?></label></th>
						<td>
							<select id="mge_card_template" name="mge_card_template">
								<?php foreach ( self::templates() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $template, $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'A quick-start color scheme for every card, grid, and the homepage ticker.', 'mge' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="mge_title_color"><?php esc_html_e( 'Event Title Color', 'mge' ); ?></label></th>
						<td>
							<input type="text" id="mge_title_color" name="mge_title_color" class="mge-color-picker" value="<?php echo esc_attr( get_option( 'mge_title_color', '' ) ); ?>" data-default-color="" />
							<p class="description"><?php esc_html_e( 'Optional. Overrides the event name color from the template above. Clear it to go back to the template default.', 'mge' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="mge_tile_size"><?php esc_html_e( 'Tile Size', 'mge' ); ?></label></th>
						<td>
							<select id="mge_tile_size" name="mge_tile_size">
								<?php foreach ( self::sizes() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $size, $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Controls padding, icon size, and text size for every event card, including the homepage ticker.', 'mge' ); ?></p>
						</td>
					</tr>
				</table>
				<p class="description">
					<?php esc_html_e( 'Tip: choose which events are eligible for the homepage ticker from the "Homepage Ticker" checkbox on each individual event, inside the post editor.', 'mge' ); ?>
				</p>
				<?php submit_button(); ?>
			</form>

			<hr />

			<h2><?php esc_html_e( 'Shortcodes', 'mge' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Every category gets its own shortcode automatically — including any new category you add. Placing one inside a post only shows the events on that specific post that are set to that category; it never pulls in events from other posts.', 'mge' ); ?>
			</p>
			<table class="widefat striped" style="max-width:640px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Category', 'mge' ); ?></th>
						<th><?php esc_html_e( 'Shortcode', 'mge' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$cats = get_terms( array( 'taxonomy' => 'mge_category', 'hide_empty' => false ) );
					if ( ! empty( $cats ) && ! is_wp_error( $cats ) ) :
						foreach ( $cats as $cat ) :
							?>
							<tr>
								<td><?php echo esc_html( $cat->name ); ?></td>
								<td><code>[<?php echo esc_html( MGE_Shortcodes::shortcode_tag_for_term( $cat ) ); ?>]</code></td>
							</tr>
							<?php
						endforeach;
					else :
						?>
						<tr><td colspan="2"><?php esc_html_e( 'No categories yet — add one under MGO Events → Categories.', 'mge' ); ?></td></tr>
						<?php
					endif;
					?>
					<tr>
						<td><?php esc_html_e( 'Homepage Ticker (site-wide)', 'mge' ); ?></td>
						<td><code>[mge_live_ticker]</code></td>
					</tr>
				</tbody>
			</table>
		</div>
		<?php
	}
}
