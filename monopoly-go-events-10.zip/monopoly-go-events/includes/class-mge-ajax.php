<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGE_Ajax {

	public static function init() {
		add_action( 'wp_ajax_mge_add_event_name', array( __CLASS__, 'add_event_name' ) );
	}

	public static function add_event_name() {
		check_ajax_referer( 'mge_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mge' ) ) );
		}

		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		if ( '' === $name ) {
			wp_send_json_error( array( 'message' => __( 'Name cannot be empty.', 'mge' ) ) );
		}

		$existing = term_exists( $name, 'mge_event_name' );
		if ( $existing ) {
			$term_id = is_array( $existing ) ? $existing['term_id'] : $existing;
			wp_send_json_success( array( 'term_id' => $term_id, 'name' => $name, 'existing' => true ) );
		}

		$result = wp_insert_term( $name, 'mge_event_name' );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'term_id' => $result['term_id'], 'name' => $name, 'existing' => false ) );
	}
}
