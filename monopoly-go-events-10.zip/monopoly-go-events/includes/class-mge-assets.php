<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGE_Assets {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'frontend' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin' ) );
	}

	public static function frontend() {
		if ( is_admin() ) {
			return;
		}
		wp_enqueue_style( 'mge-frontend', MGE_URL . 'assets/css/frontend.css', array(), MGE_VERSION );
		wp_enqueue_script( 'mge-frontend', MGE_URL . 'assets/js/frontend.js', array(), MGE_VERSION, true );
	}

	public static function admin( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		global $post_type;
		if ( ! in_array( $post_type, array( 'post', 'page' ), true ) ) {
			return;
		}

		wp_enqueue_media();
		wp_enqueue_style( 'mge-admin', MGE_URL . 'assets/css/admin.css', array(), MGE_VERSION );
		wp_enqueue_script( 'mge-admin', MGE_URL . 'assets/js/admin.js', array( 'jquery' ), MGE_VERSION, true );
		wp_localize_script( 'mge-admin', 'MGE_Admin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'mge_admin_nonce' ),
		) );
	}
}
