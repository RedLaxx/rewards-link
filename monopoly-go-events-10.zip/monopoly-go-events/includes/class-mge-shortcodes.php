<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGE_Shortcodes {

	public static function init() {
		add_shortcode( 'mge_live_ticker', array( __CLASS__, 'render_ticker' ) );

		// Category shortcodes are registered dynamically (one per mge_category
		// term), so this has to wait until taxonomies are registered on 'init'.
		add_action( 'init', array( __CLASS__, 'register_category_shortcodes' ), 20 );
	}

	/**
	 * One shortcode per category, e.g. "Flash Events" -> [mge_flash_events].
	 * Each only shows events that were added to (and categorized on) the
	 * specific post the shortcode is placed in — never events from other
	 * posts. Runs again on every load, so a category you add today gets its
	 * shortcode immediately, with no re-save or flush needed.
	 */
	public static function register_category_shortcodes() {
		$terms = get_terms( array( 'taxonomy' => 'mge_category', 'hide_empty' => false ) );
		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return;
		}

		foreach ( $terms as $term ) {
			$tag = self::shortcode_tag_for_term( $term );
			add_shortcode( $tag, function ( $atts ) use ( $term ) {
				return self::render_category_for_post( $term, $atts );
			} );
		}
	}

	/** "Flash Events" (slug flash-events) -> "mge_flash_events". Stable across renames since it's built from the slug, not the display name. */
	public static function shortcode_tag_for_term( $term ) {
		return 'mge_' . str_replace( '-', '_', sanitize_html_class( $term->slug ) );
	}

	private static function render_category_for_post( $term, $atts ) {
		$atts    = shortcode_atts( array( 'post_id' => 0 ), (array) $atts );
		$post_id = (int) $atts['post_id'];
		if ( ! $post_id ) {
			$post_id = get_the_ID();
		}
		if ( ! $post_id ) {
			return '';
		}

		$rows = MGE_DB::get_for_post_by_category( $post_id, $term->term_id );
		if ( empty( $rows ) ) {
			return '<p class="mge-empty">' . sprintf(
				/* translators: %s: category name */
				esc_html__( 'No %s events added to this post yet.', 'mge' ),
				esc_html( $term->name )
			) . '</p>';
		}

		ob_start();
		?>
		<div class="mge-events-grid <?php echo esc_attr( self::wrapper_classes() ); ?>" <?php echo self::wrapper_style(); ?>>
			<?php foreach ( $rows as $row ) : self::render_card( self::build_card_data( $row ), true ); endforeach; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/** [mge_live_ticker] — unchanged: site-wide, only events flagged "Homepage Ticker" that are currently live. */
	public static function render_ticker( $atts ) {
		$rows = MGE_DB::get_homepage_events( (int) get_option( 'mge_ticker_limit', 5 ) );
		if ( empty( $rows ) ) {
			return '';
		}

		ob_start();
		?>
		<div class="mge-ticker <?php echo esc_attr( self::wrapper_classes() ); ?>" <?php echo self::wrapper_style(); ?> data-mge-ticker>
			<div class="mge-ticker-label"><?php esc_html_e( 'Live Now', 'mge' ); ?></div>
			<div class="mge-ticker-cards">
				<?php foreach ( $rows as $row ) : self::render_card( self::build_card_data( $row ), false ); endforeach; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/** "mge-theme-{template} mge-size-{size}" classes, driven by Settings. */
	private static function wrapper_classes() {
		$template = get_option( 'mge_card_template', 'default' );
		$size     = get_option( 'mge_tile_size', 'medium' );
		return 'mge-theme-' . sanitize_html_class( $template ) . ' mge-size-' . sanitize_html_class( $size );
	}

	/** Inline --mge-title-color custom property, only when an override is set. */
	private static function wrapper_style() {
		$color = get_option( 'mge_title_color', '' );
		if ( ! $color ) {
			return '';
		}
		return 'style="--mge-title-color: ' . esc_attr( $color ) . ';"';
	}

	private static function build_card_data( $row ) {
		$icon = $row['icon'];
		if ( ! $icon && ! empty( $row['event_name_term_id'] ) ) {
			$icon = get_term_meta( $row['event_name_term_id'], 'mge_icon', true );
		}

		$category = '';
		if ( ! empty( $row['category_term_id'] ) ) {
			$term = get_term( $row['category_term_id'], 'mge_category' );
			if ( $term && ! is_wp_error( $term ) ) {
				$category = $term->name;
			}
		}

		return array(
			'name'      => $row['event_name'],
			'category'  => $category,
			'icon'      => $icon,
			'is_flash'  => ! empty( $row['is_flash'] ),
			'start_utc' => str_replace( ' ', 'T', $row['start_utc'] ) . 'Z',
			'end_utc'   => str_replace( ' ', 'T', $row['end_utc'] ) . 'Z',
			'duration'  => MGE_DB::format_duration( $row['duration_value'], $row['duration_unit'] ),
			'rewards'   => json_decode( $row['rewards'], true ),
		);
	}

	private static function render_card( $data, $show_rewards = true ) {
		$rewards = is_array( $data['rewards'] ) ? $data['rewards'] : array();
		?>
		<div class="mge-card" data-mge-card data-start="<?php echo esc_attr( $data['start_utc'] ); ?>" data-end="<?php echo esc_attr( $data['end_utc'] ); ?>">
			<div class="mge-card-status" data-mge-status></div>
			<div class="mge-card-head">
				<?php if ( $data['icon'] ) : ?>
					<img class="mge-card-icon" src="<?php echo esc_url( $data['icon'] ); ?>" alt="" />
				<?php endif; ?>
				<div class="mge-card-titles">
					<?php if ( $data['is_flash'] ) : ?>
						<span class="mge-flash-badge">⚡ <?php esc_html_e( 'Flash', 'mge' ); ?></span>
					<?php endif; ?>
					<h3 class="mge-card-name"><?php echo esc_html( $data['name'] ); ?></h3>
					<?php if ( $data['category'] ) : ?>
						<span class="mge-card-category"><?php echo esc_html( $data['category'] ); ?></span>
					<?php endif; ?>
				</div>
			</div>
			<div class="mge-card-time">
				<span data-mge-time></span>
			</div>
			<?php if ( $data['duration'] ) : ?>
				<div class="mge-card-duration">
					<?php esc_html_e( 'Duration:', 'mge' ); ?> <?php echo esc_html( $data['duration'] ); ?>
				</div>
			<?php endif; ?>
			<?php if ( $show_rewards && ! empty( $rewards ) ) : ?>
				<div class="mge-card-rewards">
					<?php foreach ( $rewards as $r ) : ?>
						<span class="mge-reward-pill">
							<?php if ( ! empty( $r['icon'] ) ) : ?><img src="<?php echo esc_url( $r['icon'] ); ?>" alt="" /><?php endif; ?>
							<?php echo esc_html( $r['text'] ); ?>
						</span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
