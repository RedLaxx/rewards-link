<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGE_Metaboxes {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_metaboxes' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ) );
	}

	public static function add_metaboxes() {
		foreach ( array( 'post', 'page' ) as $post_type ) {
			add_meta_box(
				'mge_events_box',
				__( 'Monopoly GO Events', 'mge' ),
				array( __CLASS__, 'render' ),
				$post_type,
				'normal',
				'high'
			);
		}
	}

	public static function render( $post ) {
		wp_nonce_field( 'mge_save_events', 'mge_nonce' );

		$events    = MGE_DB::get_for_post( $post->ID );
		$all_names = get_terms( array( 'taxonomy' => 'mge_event_name', 'hide_empty' => false ) );
		$all_cats  = get_terms( array( 'taxonomy' => 'mge_category', 'hide_empty' => false ) );
		?>
		<div class="mge-metabox">
			<p class="description">
				<?php esc_html_e( 'Add each event below and pick its category. Each category has its own shortcode — the "Category" field on each event shows you which one to use. Full list also under', 'mge' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=mge-settings' ) ); ?>" target="_blank"><?php esc_html_e( 'MGO Events → Settings', 'mge' ); ?></a>.
			</p>

			<div id="mge-events-rows">
				<?php if ( ! empty( $events ) ) : ?>
					<?php foreach ( $events as $i => $event ) : ?>
						<?php self::render_event_row( $i, $event, $all_names, $all_cats ); ?>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>

			<button type="button" class="button button-primary" id="mge-add-event"><?php esc_html_e( '+ Add Event', 'mge' ); ?></button>
		</div>

		<script type="text/template" id="mge-event-row-template">
			<?php self::render_event_row( '__INDEX__', array(), $all_names, $all_cats ); ?>
		</script>
		<script type="text/template" id="mge-reward-row-template">
			<?php self::render_reward_row( '__EVENT_INDEX__', '__REWARD_INDEX__', array() ); ?>
		</script>
		<?php
	}

	private static function render_event_row( $index, $event, $all_names, $all_cats ) {
		$name_term_id = isset( $event['event_name_term_id'] ) ? (int) $event['event_name_term_id'] : 0;
		$cat_term_id  = isset( $event['category_term_id'] ) ? (int) $event['category_term_id'] : 0;
		$icon         = isset( $event['icon'] ) ? $event['icon'] : '';
		$is_flash     = ! empty( $event['is_flash'] );
		$show_home    = ! empty( $event['show_on_homepage'] );
		$start        = isset( $event['start_local'] ) ? $event['start_local'] : '';
		$end          = isset( $event['end_local'] ) ? $event['end_local'] : '';
		$duration_value = isset( $event['duration_value'] ) ? (int) $event['duration_value'] : 0;
		$duration_unit  = isset( $event['duration_unit'] ) && $event['duration_unit'] ? $event['duration_unit'] : 'hours';
		$rewards      = isset( $event['rewards'] ) ? json_decode( $event['rewards'], true ) : array();
		$rewards      = is_array( $rewards ) ? $rewards : array();
		$label        = isset( $event['event_name'] ) && $event['event_name'] ? $event['event_name'] : __( 'New Event', 'mge' );
		?>
		<div class="mge-event-row" data-index="<?php echo esc_attr( $index ); ?>">
			<div class="mge-event-row-head">
				<strong class="mge-event-row-title"><?php echo esc_html( $label ); ?></strong>
				<button type="button" class="button-link-delete mge-remove-event"><?php esc_html_e( 'Remove Event', 'mge' ); ?></button>
			</div>

			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Event Name', 'mge' ); ?></th>
					<td>
						<select class="mge-event-name" name="mge_events[<?php echo esc_attr( $index ); ?>][name_term_id]">
							<option value=""><?php esc_html_e( '— Select an event name —', 'mge' ); ?></option>
							<?php foreach ( $all_names as $term ) : ?>
								<option value="<?php echo esc_attr( $term->term_id ); ?>" data-name="<?php echo esc_attr( $term->name ); ?>" data-icon="<?php echo esc_attr( get_term_meta( $term->term_id, 'mge_icon', true ) ); ?>" <?php selected( $name_term_id, $term->term_id ); ?>>
									<?php echo esc_html( $term->name ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<button type="button" class="button mge-add-name-toggle"><?php esc_html_e( '+ Add New Name', 'mge' ); ?></button>
						<div class="mge-add-name-row" style="display:none;margin-top:8px;">
							<input type="text" class="mge-new-name" placeholder="<?php esc_attr_e( 'New event name…', 'mge' ); ?>" />
							<button type="button" class="button button-secondary mge-add-name-save"><?php esc_html_e( 'Save Name', 'mge' ); ?></button>
							<span class="spinner" style="float:none;"></span>
						</div>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Category', 'mge' ); ?></th>
					<td>
						<select class="mge-event-category" name="mge_events[<?php echo esc_attr( $index ); ?>][category_term_id]">
							<option value=""><?php esc_html_e( '— Select a category —', 'mge' ); ?></option>
							<?php foreach ( $all_cats as $term ) : ?>
								<option value="<?php echo esc_attr( $term->term_id ); ?>" data-tag="<?php echo esc_attr( MGE_Shortcodes::shortcode_tag_for_term( $term ) ); ?>" <?php selected( $cat_term_id, $term->term_id ); ?>>
									<?php echo esc_html( $term->name ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description mge-shortcode-hint">
							<?php if ( $cat_term_id ) : ?>
								<?php
								$selected_term = get_term( $cat_term_id, 'mge_category' );
								if ( $selected_term && ! is_wp_error( $selected_term ) ) {
									printf(
										/* translators: %s: shortcode tag */
										esc_html__( 'Shortcode for this category: %s', 'mge' ),
										'<code>[' . esc_html( MGE_Shortcodes::shortcode_tag_for_term( $selected_term ) ) . ']</code>'
									);
								}
								?>
							<?php else : ?>
								<?php esc_html_e( 'Pick a category to see its shortcode.', 'mge' ); ?>
							<?php endif; ?>
						</p>
						<p class="description">
							<?php
							printf(
								/* translators: %s: link to manage categories */
								esc_html__( 'Rename or add categories under %s.', 'mge' ),
								'<a href="' . esc_url( admin_url( 'edit-tags.php?taxonomy=mge_category&post_type=post' ) ) . '" target="_blank">' . esc_html__( 'MGO Events → Categories', 'mge' ) . '</a>'
							);
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Flash Event', 'mge' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="mge_events[<?php echo esc_attr( $index ); ?>][is_flash]" value="1" <?php checked( $is_flash ); ?> />
							<?php esc_html_e( 'Mark as a flash event (shows a lightning badge).', 'mge' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Start Date & Time (GMT+1)', 'mge' ); ?></th>
					<td><input type="datetime-local" name="mge_events[<?php echo esc_attr( $index ); ?>][start]" value="<?php echo esc_attr( $start ); ?>" required /></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'End Date & Time (GMT+1)', 'mge' ); ?></th>
					<td><input type="datetime-local" name="mge_events[<?php echo esc_attr( $index ); ?>][end]" value="<?php echo esc_attr( $end ); ?>" required /></td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Duration', 'mge' ); ?></th>
					<td>
						<input type="number" min="1" step="1" style="width:90px;" name="mge_events[<?php echo esc_attr( $index ); ?>][duration_value]" value="<?php echo esc_attr( $duration_value ?: '' ); ?>" placeholder="e.g. 3" />
						<select name="mge_events[<?php echo esc_attr( $index ); ?>][duration_unit]">
							<option value="minutes" <?php selected( $duration_unit, 'minutes' ); ?>><?php esc_html_e( 'Minutes', 'mge' ); ?></option>
							<option value="hours" <?php selected( $duration_unit, 'hours' ); ?>><?php esc_html_e( 'Hours', 'mge' ); ?></option>
							<option value="days" <?php selected( $duration_unit, 'days' ); ?>><?php esc_html_e( 'Days', 'mge' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'Optional. Shown on the card as a "Duration" label — separate from the start/end times above, which are what actually control the live/upcoming/ended status. Leave the number blank to hide the label entirely.', 'mge' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Event Icon', 'mge' ); ?></th>
					<td>
						<input type="hidden" class="mge-icon-value" name="mge_events[<?php echo esc_attr( $index ); ?>][icon]" value="<?php echo esc_attr( $icon ); ?>" />
						<button type="button" class="button mge-upload-icon-btn"><?php esc_html_e( 'Select Icon', 'mge' ); ?></button>
						<button type="button" class="button mge-icon-clear" <?php echo $icon ? '' : 'style="display:none;"'; ?>><?php esc_html_e( 'Remove', 'mge' ); ?></button>
						<div class="mge-icon-preview">
							<?php if ( $icon ) : ?><img src="<?php echo esc_url( $icon ); ?>" style="max-width:60px;height:auto;display:block;margin-top:8px;" /><?php endif; ?>
						</div>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Homepage Ticker', 'mge' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="mge_events[<?php echo esc_attr( $index ); ?>][show_on_homepage]" value="1" <?php checked( $show_home ); ?> />
							<?php esc_html_e( 'Allow this event to appear in the homepage live ticker when it is live.', 'mge' ); ?>
						</label>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Rewards', 'mge' ); ?></th>
					<td>
						<div class="mge-rewards-rows" data-next-reward-index="<?php echo esc_attr( count( $rewards ) ); ?>">
							<?php foreach ( $rewards as $r_i => $r ) : ?>
								<?php self::render_reward_row( $index, $r_i, $r ); ?>
							<?php endforeach; ?>
						</div>
						<button type="button" class="button mge-add-reward"><?php esc_html_e( '+ Add Reward', 'mge' ); ?></button>
					</td>
				</tr>
			</table>
		</div>
		<?php
	}

	private static function render_reward_row( $event_index, $reward_index, $reward ) {
		$icon = isset( $reward['icon'] ) ? $reward['icon'] : '';
		$text = isset( $reward['text'] ) ? $reward['text'] : '';
		?>
		<div class="mge-reward-row" style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
			<input type="hidden" class="mge-reward-icon" name="mge_events[<?php echo esc_attr( $event_index ); ?>][rewards][<?php echo esc_attr( $reward_index ); ?>][icon]" value="<?php echo esc_attr( $icon ); ?>" />
			<button type="button" class="button mge-upload-icon-btn mge-reward-icon-btn"><?php esc_html_e( 'Icon', 'mge' ); ?></button>
			<span class="mge-reward-icon-preview"><?php if ( $icon ) : ?><img src="<?php echo esc_url( $icon ); ?>" style="width:28px;height:28px;object-fit:cover;border-radius:4px;" /><?php endif; ?></span>
			<input type="text" class="regular-text" name="mge_events[<?php echo esc_attr( $event_index ); ?>][rewards][<?php echo esc_attr( $reward_index ); ?>][text]" value="<?php echo esc_attr( $text ); ?>" placeholder="<?php esc_attr_e( 'e.g. 50 Dice Rolls', 'mge' ); ?>" />
			<button type="button" class="button-link-delete mge-remove-reward"><?php esc_html_e( 'Remove', 'mge' ); ?></button>
		</div>
		<?php
	}

	public static function save( $post_id ) {
		if ( ! isset( $_POST['mge_nonce'] ) || ! wp_verify_nonce( $_POST['mge_nonce'], 'mge_save_events' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		$posted = isset( $_POST['mge_events'] ) && is_array( $_POST['mge_events'] ) ? wp_unslash( $_POST['mge_events'] ) : array();
		$events = array();

		foreach ( $posted as $row ) {
			$name_term_id = isset( $row['name_term_id'] ) ? (int) $row['name_term_id'] : 0;
			$start        = isset( $row['start'] ) ? sanitize_text_field( $row['start'] ) : '';
			$end          = isset( $row['end'] ) ? sanitize_text_field( $row['end'] ) : '';

			// Skip fully empty rows (e.g. a row added then left untouched).
			if ( ! $name_term_id && ! $start && ! $end ) {
				continue;
			}

			$name_term = $name_term_id ? get_term( $name_term_id, 'mge_event_name' ) : null;
			$name_text = ( $name_term && ! is_wp_error( $name_term ) ) ? $name_term->name : '';

			$rewards = array();
			if ( isset( $row['rewards'] ) && is_array( $row['rewards'] ) ) {
				foreach ( $row['rewards'] as $reward_row ) {
					$icon = isset( $reward_row['icon'] ) ? esc_url_raw( $reward_row['icon'] ) : '';
					$text = isset( $reward_row['text'] ) ? sanitize_text_field( $reward_row['text'] ) : '';
					if ( $icon || $text ) {
						$rewards[] = array( 'icon' => $icon, 'text' => $text );
					}
				}
			}

			$duration_value = isset( $row['duration_value'] ) ? absint( $row['duration_value'] ) : 0;
			$duration_unit  = isset( $row['duration_unit'] ) && in_array( $row['duration_unit'], array( 'minutes', 'hours', 'days' ), true ) ? $row['duration_unit'] : '';
			if ( ! $duration_value ) {
				$duration_unit = ''; // No amount entered = no duration label at all.
			}

			$events[] = array(
				'name'             => $name_text,
				'name_term_id'     => $name_term_id,
				'category_term_id' => isset( $row['category_term_id'] ) ? (int) $row['category_term_id'] : 0,
				'icon'             => isset( $row['icon'] ) ? esc_url_raw( $row['icon'] ) : '',
				'is_flash'         => ! empty( $row['is_flash'] ),
				'show_on_homepage' => ! empty( $row['show_on_homepage'] ),
				'start'            => $start,
				'end'              => $end,
				'duration_value'   => $duration_value,
				'duration_unit'    => $duration_unit,
				'rewards'          => $rewards,
			);
		}

		MGE_DB::save_for_post( $post_id, $events );
	}
}
