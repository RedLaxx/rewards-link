<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Events are no longer their own post type. Each event belongs to whichever
 * post/page it was added on (edited right there in the post editor), and is
 * stored as a row in this table so the homepage ticker can still query
 * across the whole site efficiently.
 */
class MGE_DB {

	const SITE_OFFSET = '+01:00'; // Admin-entered times are always treated as this fixed offset.

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'mge_events';
	}

	/**
	 * Runs on every request (cheap: one get_option call in the normal case).
	 * If the table was never created — e.g. the plugin files were updated
	 * by overwriting rather than deactivate + reactivate, so the activation
	 * hook never ran — this creates it without requiring a manual reactivation.
	 */
	public static function maybe_install() {
		if ( get_option( 'mge_db_version' ) === MGE_VERSION ) {
			return;
		}
		self::install();
		update_option( 'mge_db_version', MGE_VERSION );
	}

	public static function install() {
		global $wpdb;
		$table_name      = self::table();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id BIGINT UNSIGNED NOT NULL,
			sort_order INT NOT NULL DEFAULT 0,
			event_name VARCHAR(191) NOT NULL DEFAULT '',
			event_name_term_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			category_term_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			icon VARCHAR(500) NOT NULL DEFAULT '',
			is_flash TINYINT(1) NOT NULL DEFAULT 0,
			show_on_homepage TINYINT(1) NOT NULL DEFAULT 0,
			start_local VARCHAR(20) NOT NULL DEFAULT '',
			start_utc DATETIME NOT NULL,
			end_local VARCHAR(20) NOT NULL DEFAULT '',
			end_utc DATETIME NOT NULL,
			duration_value INT UNSIGNED NOT NULL DEFAULT 0,
			duration_unit VARCHAR(10) NOT NULL DEFAULT '',
			rewards LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY post_id (post_id),
			KEY show_on_homepage (show_on_homepage),
			KEY start_utc (start_utc),
			KEY end_utc (end_utc)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/** Convert a "Y-m-d\TH:i" string (always GMT+1) to a MySQL UTC datetime. */
	public static function to_utc_mysql( $local_datetime ) {
		if ( empty( $local_datetime ) ) {
			return null;
		}
		try {
			$dt = new DateTime( str_replace( 'T', ' ', $local_datetime ), new DateTimeZone( self::SITE_OFFSET ) );
			$dt->setTimezone( new DateTimeZone( 'UTC' ) );
			return $dt->format( 'Y-m-d H:i:s' );
		} catch ( Exception $e ) {
			return null;
		}
	}

	public static function to_utc_iso( $local_datetime ) {
		$mysql = self::to_utc_mysql( $local_datetime );
		if ( ! $mysql ) {
			return '';
		}
		return str_replace( ' ', 'T', $mysql ) . 'Z';
	}

	/** All belonging to a single post, in the order the admin arranged them. */
	public static function get_for_post( $post_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM " . self::table() . " WHERE post_id = %d ORDER BY sort_order ASC, id ASC",
			$post_id
		), ARRAY_A );
		return $rows ? $rows : array();
	}

	/** Events on a single post, filtered to one category — what each per-category shortcode renders. */
	public static function get_for_post_by_category( $post_id, $category_term_id ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM " . self::table() . " WHERE post_id = %d AND category_term_id = %d ORDER BY sort_order ASC, id ASC",
			$post_id, $category_term_id
		), ARRAY_A );
		return $rows ? $rows : array();
	}

	/** Events (from any post) flagged for the homepage ticker, soonest-starting first. */
	public static function get_homepage_events( $limit = 5 ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM " . self::table() . " WHERE show_on_homepage = 1 ORDER BY start_utc ASC LIMIT %d",
			$limit
		), ARRAY_A );
		return $rows ? $rows : array();
	}

	/** Replace all events for a post with a fresh set (called on save_post). */
	public static function save_for_post( $post_id, $events ) {
		global $wpdb;
		$table = self::table();

		$wpdb->delete( $table, array( 'post_id' => $post_id ), array( '%d' ) );

		foreach ( $events as $i => $event ) {
			$start_utc = self::to_utc_mysql( $event['start'] );
			$end_utc   = self::to_utc_mysql( $event['end'] );
			if ( ! $start_utc || ! $end_utc ) {
				continue; // Skip incomplete rows rather than saving broken dates.
			}

			$wpdb->insert( $table, array(
				'post_id'             => $post_id,
				'sort_order'          => $i,
				'event_name'          => $event['name'],
				'event_name_term_id'  => (int) $event['name_term_id'],
				'category_term_id'    => (int) $event['category_term_id'],
				'icon'                => $event['icon'],
				'is_flash'            => $event['is_flash'] ? 1 : 0,
				'show_on_homepage'    => $event['show_on_homepage'] ? 1 : 0,
				'start_local'         => $event['start'],
				'start_utc'           => $start_utc,
				'end_local'           => $event['end'],
				'end_utc'             => $end_utc,
				'duration_value'      => (int) $event['duration_value'],
				'duration_unit'       => $event['duration_unit'],
				'rewards'             => wp_json_encode( $event['rewards'] ),
			), array( '%d', '%d', '%s', '%d', '%d', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s' ) );
		}
	}

	public static function count_for_post( $post_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM " . self::table() . " WHERE post_id = %d", $post_id
		) );
	}

	/** e.g. (3, 'days') -> "3 Days". Returns '' when there's no duration set. */
	public static function format_duration( $value, $unit ) {
		$value = (int) $value;
		if ( $value <= 0 || empty( $unit ) ) {
			return '';
		}
		$labels = array(
			'minutes' => _n( 'Minute', 'Minutes', $value, 'mge' ),
			'hours'   => _n( 'Hour', 'Hours', $value, 'mge' ),
			'days'    => _n( 'Day', 'Days', $value, 'mge' ),
		);
		if ( ! isset( $labels[ $unit ] ) ) {
			return '';
		}
		return $value . ' ' . $labels[ $unit ];
	}
}
