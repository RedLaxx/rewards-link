<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class MGE_Taxonomies {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_taxonomies' ) );

		// Icon field on the Event Name taxonomy (add + edit forms).
		add_action( 'mge_event_name_add_form_fields', array( __CLASS__, 'add_icon_field' ) );
		add_action( 'mge_event_name_edit_form_fields', array( __CLASS__, 'edit_icon_field' ) );
		add_action( 'created_mge_event_name', array( __CLASS__, 'save_icon_field' ) );
		add_action( 'edited_mge_event_name', array( __CLASS__, 'save_icon_field' ) );

		// Extra column showing the icon in the term list table.
		add_filter( 'manage_edit-mge_event_name_columns', array( __CLASS__, 'icon_column' ) );
		add_filter( 'manage_mge_event_name_custom_column', array( __CLASS__, 'icon_column_content' ), 10, 3 );
	}

	public static function register_taxonomies() {

		// Editable categories: Flash Events, Competitions, Milestone Events, etc.
		register_taxonomy(
			'mge_category',
			array( 'post', 'page' ),
			array(
				'labels' => array(
					'name'          => __( 'Event Categories', 'mge' ),
					'singular_name' => __( 'Category', 'mge' ),
					'menu_name'     => __( 'Categories', 'mge' ),
					'add_new_item'  => __( 'Add New Category', 'mge' ),
					'edit_item'     => __( 'Edit Category', 'mge' ),
				),
				'hierarchical'      => false,
				'public'            => false,
				'show_ui'           => true,
				'show_admin_column' => false,
				'show_in_rest'      => false,
				'meta_box_cb'       => false, // We pick a category per-event inside our own repeater, not via WP's default box.
			)
		);

		// Reusable event names, saved once and selectable next time (like tags,
		// but each term can also carry a default icon).
		register_taxonomy(
			'mge_event_name',
			array( 'post', 'page' ),
			array(
				'labels' => array(
					'name'          => __( 'Event Names', 'mge' ),
					'singular_name' => __( 'Event Name', 'mge' ),
					'menu_name'     => __( 'Event Names', 'mge' ),
					'add_new_item'  => __( 'Add New Event Name', 'mge' ),
					'edit_item'     => __( 'Edit Event Name', 'mge' ),
				),
				'hierarchical'      => false,
				'public'            => false,
				'show_ui'           => true,
				'show_admin_column' => false,
				'show_in_rest'      => false,
				'meta_box_cb'       => false,
			)
		);
	}

	public static function seed_default_categories() {
		$defaults = array(
			'Flash Events'    => 'A short, limited-time event.',
			'Competitions'    => 'Compete against other players for rewards.',
			'Milestone Events' => 'Progress-based events with tiered rewards.',
			'Tournaments'     => 'Bracket or leaderboard based events.',
		);
		foreach ( $defaults as $name => $desc ) {
			if ( ! term_exists( $name, 'mge_category' ) ) {
				wp_insert_term( $name, 'mge_category', array( 'description' => $desc ) );
			}
		}
	}

	public static function add_icon_field() {
		?>
		<div class="form-field">
			<label for="mge-term-icon"><?php esc_html_e( 'Default Icon', 'mge' ); ?></label>
			<input type="hidden" id="mge-term-icon" name="mge_term_icon" value="" />
			<button type="button" class="button mge-upload-icon-btn"><?php esc_html_e( 'Select Icon', 'mge' ); ?></button>
			<div class="mge-icon-preview"></div>
			<p><?php esc_html_e( 'Optional default icon used whenever this event name is selected in a new post.', 'mge' ); ?></p>
		</div>
		<?php
	}

	public static function edit_icon_field( $term ) {
		$icon = get_term_meta( $term->term_id, 'mge_icon', true );
		?>
		<tr class="form-field">
			<th scope="row"><label for="mge-term-icon"><?php esc_html_e( 'Default Icon', 'mge' ); ?></label></th>
			<td>
				<input type="hidden" id="mge-term-icon" name="mge_term_icon" value="<?php echo esc_attr( $icon ); ?>" />
				<button type="button" class="button mge-upload-icon-btn"><?php esc_html_e( 'Select Icon', 'mge' ); ?></button>
				<div class="mge-icon-preview">
					<?php if ( $icon ) : ?>
						<img src="<?php echo esc_url( $icon ); ?>" style="max-width:60px;height:auto;display:block;margin-top:8px;" />
					<?php endif; ?>
				</div>
			</td>
		</tr>
		<?php
	}

	public static function save_icon_field( $term_id ) {
		if ( isset( $_POST['mge_term_icon'] ) ) {
			update_term_meta( $term_id, 'mge_icon', esc_url_raw( wp_unslash( $_POST['mge_term_icon'] ) ) );
		}
	}

	public static function icon_column( $columns ) {
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'name' === $key ) {
				$new['mge_icon'] = __( 'Icon', 'mge' );
			}
		}
		return $new;
	}

	public static function icon_column_content( $content, $column_name, $term_id ) {
		if ( 'mge_icon' === $column_name ) {
			$icon = get_term_meta( $term_id, 'mge_icon', true );
			if ( $icon ) {
				$content = '<img src="' . esc_url( $icon ) . '" style="width:32px;height:32px;object-fit:cover;border-radius:6px;" />';
			}
		}
		return $content;
	}
}
