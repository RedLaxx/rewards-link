(function ($) {
	'use strict';

	$(function () {
		var $metabox = $('.mge-metabox');
		var eventIndex = $('#mge-events-rows .mge-event-row').length;

		/* ---------- Add / remove events ---------- */

		$('#mge-add-event').on('click', function (e) {
			e.preventDefault();
			var template = $('#mge-event-row-template').html();
			var html = template.split('__INDEX__').join(eventIndex++);
			$('#mge-events-rows').append(html);
		});

		$(document).on('click', '.mge-remove-event', function (e) {
			e.preventDefault();
			if (window.confirm('Remove this event?')) {
				$(this).closest('.mge-event-row').remove();
			}
		});

		/* ---------- Icon picker (event icon + reward icons) ---------- */

		$(document).on('click', '.mge-upload-icon-btn', function (e) {
			e.preventDefault();
			var $button = $(this);
			var $scope = $button.closest('td, .mge-reward-row');
			var $hidden = $scope.find('input[type="hidden"]').first();
			var $preview = $scope.find('.mge-icon-preview, .mge-reward-icon-preview').first();

			var frame = wp.media({ title: 'Select Icon', multiple: false, library: { type: 'image' } });
			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				$hidden.val(attachment.url);
				$preview.html('<img src="' + attachment.url + '" style="max-width:60px;height:auto;display:block;margin-top:8px;" />');
				$button.siblings('.mge-icon-clear').show();
			});
			frame.open();
		});

		$(document).on('click', '.mge-icon-clear', function (e) {
			e.preventDefault();
			var $td = $(this).closest('td');
			$td.find('.mge-icon-value').val('');
			$td.find('.mge-icon-preview').empty();
			$(this).hide();
		});

		/* ---------- Add new event name via AJAX ---------- */

		$(document).on('click', '.mge-add-name-toggle', function () {
			$(this).siblings('.mge-add-name-row').slideToggle(150);
		});

		$(document).on('click', '.mge-add-name-save', function () {
			var $btn = $(this);
			var $row = $btn.closest('.mge-add-name-row');
			var $select = $row.siblings('.mge-event-name');
			var name = $row.find('.mge-new-name').val().trim();
			if (!name) { return; }

			$btn.prop('disabled', true).siblings('.spinner').addClass('is-active');

			$.post(MGE_Admin.ajaxUrl, {
				action: 'mge_add_event_name',
				nonce: MGE_Admin.nonce,
				name: name
			}).done(function (res) {
				if (res.success) {
					var opt = new Option(res.data.name, res.data.term_id, true, true);
					$select.append(opt).trigger('change');
					$row.find('.mge-new-name').val('');
					$row.slideUp(150);
				} else {
					alert(res.data && res.data.message ? res.data.message : 'Could not add name.');
				}
			}).fail(function () {
				alert('Could not add name. Please try again.');
			}).always(function () {
				$btn.prop('disabled', false).siblings('.spinner').removeClass('is-active');
			});
		});

		/* When picking a name that has a default icon, use it if this event has no icon yet */
		$(document).on('change', '.mge-event-name', function () {
			var icon = $(this).find(':selected').data('icon');
			var $eventRow = $(this).closest('.mge-event-row');
			var $iconField = $eventRow.find('.mge-icon-value').first();
			if (icon && !$iconField.val()) {
				$iconField.val(icon);
				$iconField.closest('td').find('.mge-icon-preview').html('<img src="' + icon + '" style="max-width:60px;height:auto;display:block;margin-top:8px;" />');
				$iconField.closest('td').find('.mge-icon-clear').show();
			}
			// Update the row's header label to match, for readability while editing.
			var name = $(this).find(':selected').data('name');
			if (name) {
				$eventRow.find('.mge-event-row-title').text(name);
			}
		});

		/* Keep the "shortcode for this category" hint in sync as the category changes */
		$(document).on('change', '.mge-event-category', function () {
			var $selected = $(this).find(':selected');
			var tag = $selected.data('tag');
			var $hint = $(this).siblings('.mge-shortcode-hint');
			if (tag) {
				$hint.html('Shortcode for this category: <code>[' + tag + ']</code>');
			} else {
				$hint.text('Pick a category to see its shortcode.');
			}
		});

		/* ---------- Rewards sub-repeater (per event) ---------- */

		$(document).on('click', '.mge-add-reward', function (e) {
			e.preventDefault();
			var $eventRow = $(this).closest('.mge-event-row');
			var eventIdx = $eventRow.data('index');
			var $container = $eventRow.find('.mge-rewards-rows').first();
			var rewardIdx = $container.data('next-reward-index') || 0;

			var template = $('#mge-reward-row-template').html();
			var html = template.split('__EVENT_INDEX__').join(eventIdx).split('__REWARD_INDEX__').join(rewardIdx);
			$container.append(html);
			$container.data('next-reward-index', rewardIdx + 1);
		});

		$(document).on('click', '.mge-remove-reward', function (e) {
			e.preventDefault();
			$(this).closest('.mge-reward-row').remove();
		});
	});
})(jQuery);
