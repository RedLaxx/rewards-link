(function () {
	'use strict';

	function formatLocal(dateA, dateB) {
		try {
			var optsDate = { month: 'short', day: 'numeric' };
			var optsTime = { hour: 'numeric', minute: '2-digit' };
			var sameDay = dateA.toDateString() === dateB.toDateString();
			var startStr = dateA.toLocaleDateString(undefined, optsDate) + ', ' + dateA.toLocaleTimeString(undefined, optsTime);
			var endStr = sameDay
				? dateB.toLocaleTimeString(undefined, optsTime)
				: dateB.toLocaleDateString(undefined, optsDate) + ', ' + dateB.toLocaleTimeString(undefined, optsTime);
			return startStr + ' – ' + endStr;
		} catch (e) {
			return '';
		}
	}

	function updateCard(card) {
		var startAttr = card.getAttribute('data-start');
		var endAttr = card.getAttribute('data-end');
		if (!startAttr || !endAttr) { return; }

		var start = new Date(startAttr);
		var end = new Date(endAttr);
		var now = new Date();

		var statusEl = card.querySelector('[data-mge-status]');
		var timeEl = card.querySelector('[data-mge-time]');

		card.classList.remove('mge-live', 'mge-upcoming', 'mge-ended');

		var label = '';
		if (now < start) {
			card.classList.add('mge-upcoming');
			label = 'Upcoming';
		} else if (now > end) {
			card.classList.add('mge-ended');
			label = 'Ended';
		} else {
			card.classList.add('mge-live');
			label = 'Live';
		}

		if (statusEl) { statusEl.textContent = label; }
		if (timeEl) { timeEl.textContent = formatLocal(start, end); }
	}

	function tick() {
		var cards = document.querySelectorAll('[data-mge-card]');
		cards.forEach(updateCard);
	}

	document.addEventListener('DOMContentLoaded', function () {
		tick();
		setInterval(tick, 15000); // re-check every 15s so status flips live without a page reload
	});
})();
