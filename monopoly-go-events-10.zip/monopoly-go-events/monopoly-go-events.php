<?php
/**
 * Plugin Name: Monopoly GO Events
 * Plugin URI:  https://example.com/monopoly-go-events
 * Description: Add Monopoly GO events (competitions, milestones, flash events) directly inside the post editor, then place them anywhere in the post with a shortcode. Includes live/upcoming/ended status synced to each visitor's local time, plus a homepage live ticker.
 * Version:     2.4.0
 * Author:      Your Site
 * Text Domain: mge
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'MGE_VERSION', '2.4.0' );
define( 'MGE_PATH', plugin_dir_path( __FILE__ ) );
define( 'MGE_URL', plugin_dir_url( __FILE__ ) );

require_once MGE_PATH . 'includes/class-mge-db.php';
require_once MGE_PATH . 'includes/class-mge-taxonomies.php';
require_once MGE_PATH . 'includes/class-mge-metaboxes.php';
require_once MGE_PATH . 'includes/class-mge-ajax.php';
require_once MGE_PATH . 'includes/class-mge-shortcodes.php';
require_once MGE_PATH . 'includes/class-mge-assets.php';
require_once MGE_PATH . 'includes/class-mge-settings.php';

/**
 * Core plugin bootstrap.
 */
final class Monopoly_GO_Events {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		MGE_DB::maybe_install();
		MGE_Taxonomies::init();
		MGE_Metaboxes::init();
		MGE_Ajax::init();
		MGE_Shortcodes::init();
		MGE_Assets::init();
		MGE_Settings::init();

		register_activation_hook( __FILE__, array( __CLASS__, 'activate' ) );
	}

	public static function activate() {
		MGE_DB::install();
		MGE_Taxonomies::register_taxonomies();
		MGE_Taxonomies::seed_default_categories();
		flush_rewrite_rules();
	}
}

Monopoly_GO_Events::instance();
